# 03 — Arquitetura de dados e CMS-first

Objetivo duplo: **(a)** dissolver a sociedade nos dados sem perder histórico e **(b)** eliminar todo conteúdo hardcoded, para que o escritório opere sem depender de deploy.

---

## Parte A — Dissolução da sociedade nos dados

### A1. O problema

`'gabrielly'` está gravado como **valor de enum** em 6 collections. Remover a opção sem migrar corrompe registros existentes.

| Collection | Campo | Arquivo |
|---|---|---|
| Posts | `author` | `collections/Posts.ts:34-36` |
| PracticeAreas | `responsible` | `collections/PracticeAreas.ts:36-37` |
| Leads | `assignedTo` | `collections/Leads.ts:160-161` |
| Clients | `responsible` | `collections/Clients.ts:31-32` |
| Deadlines | `attorney` | `collections/Deadlines.ts:67-68` |
| NpsResponses | `attorney` | `collections/NpsResponses.ts:47-48` |

### A2. Solução — collection `Team`

Substituir enums por relacionamento. Ganho permanente: contratar um associado passa a ser cadastro, não deploy.

```ts
// src/collections/Team.ts
export const Team: CollectionConfig = {
  slug: 'team',
  labels: { singular: 'Advogado', plural: 'Equipe' },
  admin: { useAsTitle: 'name', defaultColumns: ['name','role','oab','active'] },
  access: {
    read: () => true,                    // público: aparece no site
    create: adminOnly, update: adminOnly, delete: adminOnly,
  },
  fields: [
    { name: 'name', type: 'text', required: true },          // "Dr. Edivaldo Cavalcante Albuquerque"
    { name: 'shortName', type: 'text' },                     // "Dr. Edivaldo"
    { name: 'slug', type: 'text', unique: true, index: true },
    { name: 'role', type: 'text', required: true },          // "Advogado Titular"
    { name: 'oab', type: 'text' },                           // "OAB/RN 12.345"
    { name: 'email', type: 'email' },                        // roteamento de prazos e leads
    { name: 'whatsapp', type: 'text' },
    { name: 'bio', type: 'richText' },
    { name: 'photo', type: 'upload', relationTo: 'media' },
    { name: 'practiceAreas', type: 'relationship', relationTo: 'practice-areas', hasMany: true },
    { name: 'linkedin', type: 'text' },
    { name: 'lattes', type: 'text' },
    { name: 'order', type: 'number', defaultValue: 0 },
    { name: 'active', type: 'checkbox', defaultValue: true, index: true },
    { name: 'showOnSite', type: 'checkbox', defaultValue: true },
    // Histórico: permite manter autoria de posts antigos sem exibir no site
    { name: 'formerMember', type: 'checkbox', defaultValue: false,
      admin: { description: 'Ex-integrante. Mantém autoria em conteúdo antigo, some do site.' } },
  ],
}
```

Cada campo enum vira:
```ts
{ name: 'assignedTo', type: 'relationship', relationTo: 'team',
  filterOptions: { active: { equals: true } } }
```

### A3. Migração — procedimento obrigatório e reversível

Ordem estrita. **Nada disso roda sem backup.**

```
Passo 0  pg_dump completo com timestamp. Verificar que o dump restaura em base limpa.
         Sem esse teste, não prosseguir.

Passo 1  Criar a collection Team. Migration Payload. Nenhum campo antigo é tocado ainda.

Passo 2  Seed de dois registros:
           • Dr. Edivaldo — active: true,  showOnSite: true,  formerMember: false
           • Dra. Gabrielly — active: false, showOnSite: false, formerMember: true
         O segundo registro EXISTE para preservar a autoria histórica. Não é exibido.

Passo 3  Adicionar os campos relacionais NOVOS ao lado dos enums antigos.
         Nomes temporários: assignedToRef, authorRef, responsibleRef, attorneyRef.
         Ambos convivem. Zero risco.

Passo 4  Script de backfill (idempotente, com --dry-run):
           'edivaldo'   → id do Dr. Edivaldo
           'gabrielly'  → id da Dra. Gabrielly (registro inativo)
           'escritorio' → null + flag byFirm: true
           'both'       → null + flag byFirm: true
         Relatório: total lido, total escrito, não mapeados. Zero não mapeados para seguir.

Passo 5  Trocar a leitura no frontend para o campo novo. Deploy. Observar 48h.

Passo 6  Só então: remover os enums antigos e renomear os campos Ref → nome final.
         Migration de drop de coluna.

Passo 7  Retirar do site tudo que referencie a ex-sócia:
           • Posts com author = Gabrielly → decisão editorial do cliente, item a item:
             despublicar, reatribuir ao escritório, ou manter com crédito histórico.
             NÃO decidir isso automaticamente — é conteúdo assinado por terceiro.
           • PracticeAreas com responsible = Gabrielly → reatribuir ao Dr. Edivaldo
           • Clients / Deadlines / Leads em aberto → reatribuir (operacional)
           • Testimonials que citem a ex-sócia pelo nome → revisar
```

> **Ponto sensível:** artigos assinados por outra advogada envolvem direito moral de autor e, se ela deixou a sociedade, também imagem e nome. A decisão de despublicar, reatribuir ou manter crédito é do Dr. Edivaldo, preferencialmente alinhada com a ex-sócia. O agente executa a decisão; não a toma.

---

## Parte B — Zero hardcode

### B1. Novos globals

#### `brand-config` — identidade institucional (fonte única)

```
Aba Identidade
  legalName, tradeName, tagline, cnpj, oabRegistration, foundedYear
  logoLight (upload), logoDark (upload), symbol (upload), ogDefault (upload), favicon (upload)

Aba Contato
  email, phone, whatsapp, whatsappDefaultMessage
  addressStreet, addressDistrict, addressCity, addressState, addressZip
  latitude, longitude            → alimenta o JSON-LD e o mapa
  businessHours[]                 → dia, abre, fecha
  emergencyLine, emergencyLabel   → "Plantão criminal 24h"

Aba Redes
  instagram, linkedin, facebook, youtube, googleBusiness
  (campo vazio = ícone não renderiza)

Aba Jurídico / LGPD
  privacyPolicy (richText), termsOfUse (richText), cookiePolicy (richText)
  dpoName, dpoEmail               → Encarregado, art. 41 LGPD
  oabDisclaimer (textarea)        → aviso do Provimento 205/2021 no rodapé
```

#### `navigation` — menus

```
headerLinks[]   { label, href, highlight?: boolean }
footerColumns[] { title, links[] { label, href } }
legalLinks[]    { label, href }
ctaLabel, ctaHref
```

Elimina os arrays de `Header.tsx` e `Footer.tsx`.

#### `automation-config` — controle das automações (ver spec 04)

```
newsEnabled, newsIntervalHours, newsAutoPublishScore (0–100), newsRetentionDays
leadAutoReply (bool), leadAutoReplyTemplate, leadSlaHours, leadEscalationEmail
deadlineAlertsEnabled, deadlineAlertDays[] (ex: 7,3,1,0), deadlineAlertHour
datajudSyncEnabled, datajudSyncHour
npsTriggerDays, npsAutoTestimonial (bool)
socialAutoGenerate (bool)
```

Cada automação passa a ter liga/desliga e parâmetro no admin, sem tocar em código.

### B2. Homepage por blocos

Hoje a home é uma sequência fixa em `page.tsx`. Converter para campo `blocks` no global `homepage`, permitindo reordenar, ativar e desativar seções pelo admin.

```ts
blocks: [
  HeroBlock,           // título, subtítulo, imagem/vídeo de fundo, CTAs, variante
  TrustBarBlock,       // estatísticas
  PracticeAreasBlock,  // filtro, quantidade, layout (grid|lista)
  UrgencyBlock,        // faixa criminal, com janela de exibição por data
  TeamBlock,
  CampaignsBlock,
  TestimonialsBlock,
  NewsBlock,
  PostsBlock,
  FaqBlock,            // NOVO — bom para SEO e para rich snippet
  ContactBlock,
  RichTextBlock,       // bloco livre
]
```

Cada bloco carrega `anchorId`, `background: 'light' | 'dark'`, `visible: boolean`, `visibleFrom`/`visibleUntil` (datas).

### B3. Collections novas

| Collection | Para quê |
|---|---|
| `Faqs` | Pergunta, resposta, área, ordem. Alimenta bloco de FAQ + `FAQPage` JSON-LD |
| `Cases` | Casos de sucesso **anonimizados** — sem nome de parte, sem número de processo, sem valor. Ver aviso abaixo |
| `AutomationRuns` | Log de execução de cada job: tipo, início, fim, status, itens processados, erro |
| `AuditLog` | Quem alterou o quê e quando — exigência prática de LGPD |

> **Sobre `Cases`:** publicar resultado de processo é terreno minado no Provimento 205/2021 da OAB (veda divulgação de resultado como isca e exige sigilo). Se for implementado, deve ser: sem identificação da parte, sem valores, sem "ganhamos", redigido como explicação de tese jurídica. Recomendo validação com a Comissão de Fiscalização da OAB/RN antes de publicar. Se houver dúvida, não implemente esta collection.

### B4. Ajustes nas collections existentes

| Collection | Ajuste |
|---|---|
| `PracticeAreas` | `icon` como select fechado (hoje aceita qualquer coisa); adicionar `heroImage`, `faqs` (relação), `seoTitle`, `seoDescription` |
| `Posts` | `readingTime` calculado em hook `beforeChange`; `relatedPosts`; `seo` group; `author` → relação Team |
| `Campaigns` | `startsAt`/`endsAt` com auto-arquivamento por hook; `conversionGoal` |
| `NewsArticles` | `sourceHash` único (dedupe real); `relevanceScore`; `aiSummary`; `expiresAt` |
| `Clients` | `accessToken` → hash + `tokenExpiresAt`; `processNumbers` como array estruturado |
| `Media` | `caption`, `credit`; `focalPoint` para recorte inteligente |
| Todas | `versions: { drafts: true }` onde faz sentido; hook `afterChange` chamando revalidate |

### B5. Fonte única — depois

```
Nome do escritório     brand-config.tradeName
Contato                brand-config.*
Menu                   navigation.*
Autoria                team (relação)
Textos das seções      site-config / blocos da homepage
Áreas no rodapé        practice-areas (query)
JSON-LD                brand-config + collection da rota
Assinatura de e-mail   brand-config
Cards de rede social   brand-config + post/campanha
```

Zero literal de marca em componente. Trocar o telefone do escritório passa a ser uma edição no admin que se propaga para header, rodapé, JSON-LD, e-mails e cards.
