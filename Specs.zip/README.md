# Cavalcante Albuquerque — pacote de rebranding e evolução do site

Especificação completa para migrar o site institucional de **Cavalcante & Melo** para **Cavalcante Albuquerque**, com o Dr. Edivaldo como titular único, e transformar a plataforma em um sistema que opera sozinho.

Base analisada: `siteCM-main` — Next.js 16 · Payload CMS 3.80 · PostgreSQL · Tailwind v4 · 138 arquivos · ~11.700 linhas em `src/`.

---

## Documentos

| # | Arquivo | Conteúdo |
|---|---|---|
| 00 | `00-DIAGNOSTICO.md` | O que existe, o que quebra, 35 ocorrências da marca antiga mapeadas com arquivo e linha, 10 riscos de segurança |
| 01 | `01-DESIGN-SYSTEM.md` | Paleta amostrada dos logos, tipografia, elemento assinatura, uso da marca, voz de interface |
| 02 | `02-SPEC-REBRAND.md` | Execução arquivo por arquivo, pipeline de assets, SEO, migração de domínio |
| 03 | `03-SPEC-DADOS-CMS.md` | Dissolução da sociedade nos dados (com migração reversível) e eliminação de todo hardcode |
| 04 | `04-SPEC-AUTOMACOES.md` | Sete motores de automação, agendador, contratos de webhook, variáveis de ambiente |
| 05 | `05-SPEC-SEGURANCA-LGPD.md` | Matriz de acesso, autenticação, LGPD, conformidade OAB |
| 06 | `06-SPEC-DINAMISMO-UX.md` | ISR, personalização, movimento, performance, acessibilidade |
| 07 | `07-BACKLOG-AGENTE.md` | 40 tickets com prompts prontos, critérios de pronto, ordem e marcos de aprovação |

## Arquivos prontos para uso

| Arquivo | O que é |
|---|---|
| `assets/tokens.css` | Substitui integralmente `src/styles/globals.css`. Cores amostradas dos logos, tipografia, componentes base, elemento assinatura |
| `assets/ca-symbol.svg` | Símbolo vetorizado por medição do bitmap. Pronto para favicon, header e ícone |

---

## Os cinco achados que mudam o plano

**1. A paleta da nova marca não tem dourado.** O site atual é navy + dourado `#c4a96a` (47 ocorrências). Os logos enviados são navy profundo `#011536` + aço escovado. Não é ajuste de tom — é troca de sistema.

**2. A ex-sócia está gravada como valor de banco, não como registro.** `'gabrielly'` é opção de enum em 6 collections. Remover sem migrar corrompe posts, leads, clientes e prazos. É o único ponto do projeto onde um erro apaga histórico.

**3. As APIs de dados de clientes estão abertas.** Seis collections com `access: () => true` em leitura, criação, alteração e exclusão. Hoje qualquer pessoa consegue baixar a base de leads e apagar registros via `/api/leads`. Isso precede qualquer discussão de design.

**4. A automação já está construída — e desligada.** Rota de revalidação escrita e nunca chamada. DataJud integrado mas só sob demanda. Alerta de prazo pronto sem cron. Notícias importadas e nunca aprovadas. O trabalho aqui é conectar, não construir do zero.

**5. Cinco dados institucionais estão pendentes.** Razão social, CNPJ, registro OAB da nova sociedade, grafia completa do titular e confirmação de endereço. Publicar qualquer um deles errado, em site de advocacia, é infração. Estão marcados como `__PENDENTE__` nas specs — o agente não deve inventá-los.

---

## Como usar com o agente de IA

1. Entregue a pasta inteira ao agente.
2. Cole as **Regras permanentes** (`07-BACKLOG-AGENTE.md`, topo) no início de cada sessão.
3. Execute um ticket por vez, em branch própria.
4. Não avance nos cinco marcos de revisão humana sem aprovação.

**Ordem inegociável:** Segurança → Dados → Marca → CMS → Performance → Automação.
Rebranding sobre base insegura só aumenta o alcance do problema.

---

## Prazo

| Frente | Estimativa |
|---|---|
| Segurança + dissolução da sociedade | 2 semanas |
| Identidade visual + CMS-first | 3 semanas |
| Performance, acessibilidade, go-live | 2 semanas |
| Automação (após o site no ar) | 4 semanas |

**Site novo no ar em 7 semanas.** As automações entram depois, uma por vez, sem bloquear o lançamento.

---

## Pontos que dependem de decisão do cliente

- Destino de cada conteúdo assinado pela ex-sócia (direito de autor e de imagem — decisão dele, idealmente alinhada com ela)
- Os cinco dados institucionais pendentes
- Texto da comunicação de mudança de nome (não pode sugerir continuidade societária se houve dissolução)
- Se a collection de casos de sucesso será implementada (risco alto no Provimento OAB 205/2021)
- Se a triagem por IA sobre descrição de caso será ativada (sigilo profissional — recomendo pseudonimização e previsão no contrato de honorários)
