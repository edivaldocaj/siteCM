# 00 — Diagnóstico do site atual

Base analisada: `siteCM-main` (Next.js 16.2.1 · React 19.2.4 · Payload CMS 3.80 · PostgreSQL · Tailwind v4 · framer-motion 12).
Data da análise: agosto/2026.

---

## 1. O que já existe e é bom

O site é bem mais do que um institucional. Há uma camada de operação jurídica embutida que vale preservar:

| Módulo | Estado | Arquivo |
|---|---|---|
| CMS completo (15 collections + 2 globals) | Funcional | `src/payload.config.ts` |
| Funil de leads com scoring 0–100 | Funcional | `src/app/api/leads/route.ts` |
| Kanban de leads | Funcional | `admin-tools/leads-kanban` |
| Landing pages de campanha com countdown, vídeo, share bar, tracking | Funcional | `src/components/campaigns/*` |
| Integração DataJud (CNJ) | Funcional | `src/lib/datajud.ts` |
| Portal do cliente com consulta processual | Funcional | `(frontend)/cliente` |
| Gerador de cards para redes (canvas 1080×1080 / 1080×1920) | Funcional | `admin-tools/cards` |
| Gerador de minutas com IA (Claude) + base de jurisprudência | Funcional | `api/petition-generator` |
| Controle de prazos com alerta por e-mail | Funcional | `api/deadlines` |
| Pesquisa NPS | Funcional | `components/portal/NpsSurvey` |
| Agregador de notícias jurídicas (RSS + Google News) | Funcional | `api/news-feed` |
| Rota de revalidação ISR | **Escrita, mas nunca chamada** | `api/revalidate` |

Conclusão: a base de automação existe. O problema não é falta de recursos — é que **os recursos estão desconectados uns dos outros e ninguém os dispara sozinho**.

---

## 2. Bloqueadores da nova marca

### 2.1 Marca antiga espalhada em código (35 ocorrências)

| Arquivo | Linha(s) | Ocorrência |
|---|---|---|
| `src/app/(frontend)/layout.tsx` | 10, 12–13, 18, 35 | metadataBase, title default/template, openGraph.siteName, JSON-LD `name` |
| `src/components/layout/Header.tsx` | 39–48 | Logo textual `"CM"` + `"Cavalcante & Melo"` + `"Sociedade de Advogados"` |
| `src/components/layout/Footer.tsx` | 51, 118, 133 | Nome, e-mail `contato@cavalcantemelo.adv.br`, copyright |
| `src/components/sections/AboutPartners.tsx` | 15, 24 | Sócios fallback (Edivaldo + Gabrielly) |
| `src/components/sections/RecentPosts.tsx` | 7–10, 100 | Mapa `authorNames` |
| `src/app/(frontend)/blog/page.tsx` | 14, 103 | Mapa `authorNames` (duplicado) |
| `src/app/(frontend)/blog/[slug]/page.tsx` | 12–14, 71 | Mapa `authorNames` (duplicado) |
| `src/app/(frontend)/areas-de-atuacao/AreasPageClient.tsx` | 14–15 | Mapa `authorNames` (duplicado) |
| `src/app/(frontend)/sobre/AboutPageClient.tsx` | 18, 25, 34, 45 | Sócios, timeline "Fundação 2025", texto histórico |
| `src/app/(frontend)/cliente/page.tsx` | 211, 347 | Razão social |
| `src/app/(frontend)/calculadora/page.tsx` | 468 | Rodapé do laudo |
| `src/app/(frontend)/admin-tools/cards/page.tsx` | 80, 155 | Watermark `"CM"` e rodapé `"CAVALCANTE & MELO"` no canvas |
| `src/app/(frontend)/admin-tools/page.tsx` | 58 | Cabeçalho |
| `src/app/(frontend)/admin-tools/dashboard/page.tsx` | 88, 173 | Cabeçalho + nomes dos advogados |
| `src/components/admin/AdminLoginGate.tsx` | 34, 73 | Marca d'água `"CM"` gigante + título |
| `src/components/portal/NpsSurvey.tsx` | 277 | Placeholder do textarea |
| `src/app/api/{leads,contact,nps,deadlines}/route.ts` | vários | Remetente e destinatário dos e-mails |
| `src/payload.config.ts` | 35 | `admin.meta.titleSuffix` |
| `src/globals/SiteConfig.ts` | 118 | `defaultValue` do e-mail |
| `src/globals/Homepage.ts` | 20 | Label do campo com exemplo "Dr. Edivaldo Cavalcante" |
| `.github/workflows/deploy.yml` | 19, 31 | Path do servidor + nome do processo pm2 |
| `README.md` | todo | Documentação |

### 2.2 A sócia aparece como valor de enum em 6 collections

`'gabrielly'` está gravado como **valor de banco**, não como registro:

- `Posts.author` — opções `edivaldo | gabrielly | escritorio | both`
- `PracticeAreas.responsible`
- `Leads.assignedTo`
- `Clients.responsible`
- `Deadlines.attorney`
- `NpsResponses.attorney`

**Implicação crítica:** simplesmente remover a opção do enum quebra todos os registros existentes que a referenciam (posts publicados, leads atribuídos, clientes, prazos). Isso exige **migração de dados**, não só edição de código. É o único ponto do projeto onde um erro apaga histórico.

### 2.3 A paleta atual não é a paleta da nova marca

| | Marca antiga (código) | Marca nova (logos enviados) |
|---|---|---|
| Fundo escuro | `#152138` (azul-acinzentado) | `#011536` / `#041834` (navy quase preto, muito mais saturado) |
| Acento | **Dourado `#c4a96a`** | **Metálico prata/platina** (`#5C646E → #EEF1F4 → #8B98AC`) |
| Fundo claro | `#faf8f5` (creme) | `#F8F6F4` / `#FBFAFA` (osso, mais frio) |
| Display | Playfair Display | Serifa de alto contraste, caixa alta, tracking largo (tipo Cormorant) |

O dourado aparece **47 vezes** em `style={{}}` inline e classes. Não é uma troca de variável — está espalhado como literal hexadecimal.

---

## 3. Dívida técnica que impede autonomia

### 3.1 A home não tem cache
`src/app/(frontend)/page.tsx:15` → `export const dynamic = 'force-dynamic'`.
Toda visita executa 7 queries no Postgres. Sem ISR, sem cache tag. A rota `/api/revalidate` existe e está correta, mas **nenhuma collection tem hook `afterChange` que a chame**. A infraestrutura de publicação instantânea está construída e desligada.

### 3.2 Estilo inline em praticamente todo componente
Tailwind v4 está instalado e configurado (`@theme` em `globals.css`), mas 90% do layout usa `style={{}}`. Consequências: impossível trocar tema por token, impossível dark/light, CSS não é purgado, hover feito com `onMouseEnter` manipulando `style` (não funciona com teclado, quebra acessibilidade).

### 3.3 CSS do template Payload ainda ativo
`src/app/(frontend)/styles.css` é boilerplate do template e está importado no layout do frontend (`layout.tsx:2`). Contém:
```css
html { background: rgb(0, 0, 0); }
body { color: rgb(1000, 1000, 1000); }   /* valor inválido */
html { font-size: 18px; line-height: 32px; }
```
Conflita com `globals.css` e força `font-size` base de 18px em todo o site.

### 3.4 Fonte única de verdade duplicada
`authorNames` está copiado em 4 arquivos. Dados de contato existem em 3 lugares (SiteConfig, Footer hardcoded, JSON-LD hardcoded) — e **divergem**: o Footer mostra `(84) 99999-9999` (placeholder) enquanto o SiteConfig tem `(84) 99124-3985`.

### 3.5 Navegação hardcoded
`Header.navLinks` e `Footer.practiceAreas`/`navLinks` são arrays em código. Adicionar uma área de atuação exige deploy.

### 3.6 Sem SEO técnico
Não existe: `sitemap.ts`, `robots.ts`, `favicon.ico`, `apple-icon`, `manifest.webmanifest`, imagem OG padrão, canonical. O único asset em `public/` é `logo-cm.png` — e nenhum componente o utiliza.

### 3.7 Duas estratégias de deploy em conflito
`.github/workflows/deploy.yml` faz SSH → `/var/www/cavalcantemelo` → `pm2 reload`. O `README.md` e o `Dockerfile` descrevem EasyPanel + Docker. O `docker-compose.yml` ainda sobe **MongoDB** (template original) enquanto o projeto usa Postgres.

### 3.8 Rotas órfãs
`src/app/my-route/route.ts` — boilerplate do template, exposto em produção.

---

## 4. Riscos de segurança e LGPD — corrigir antes de qualquer outra coisa

Estes itens são **bloqueantes**. Alguns configuram exposição de dados pessoais de clientes.

| # | Risco | Onde | Impacto |
|---|---|---|---|
| S1 | `access: { read, create, update, delete: () => true }` em **Leads, ClientDocuments, Deadlines, NpsResponses, CampaignEvents, Jurisprudence** | `src/collections/*.ts` | Qualquer pessoa pode listar, alterar e **apagar** toda a base de leads e documentos de clientes via `GET/DELETE /api/leads`. Vazamento de dado pessoal e sensível. Violação direta da LGPD art. 46. |
| S2 | Globals `site-config` e `homepage` com `update: () => true` | `src/globals/*.ts` | Qualquer pessoa reescreve todo o conteúdo do site sem autenticar. |
| S3 | `Clients.accessToken` é campo `text` legível pela API pública | `src/collections/Clients.ts:37` | O token de acesso ao portal do cliente pode ser lido em massa e usado para acessar processos de terceiros. |
| S4 | Autenticação do `/admin-tools` é **só client-side** (`useState`), com um único bearer compartilhado | `components/admin/AdminAuthContext.tsx` | O gate é cosmético: as rotas de API atrás dele aceitam qualquer requisição com o segredo, e o segredo circula em texto no browser. |
| S5 | O mesmo segredo (`NEWS_REVALIDATE_SECRET`) autoriza news-feed, revalidate, deadlines e petition-generator | 5 rotas | Um vazamento compromete tudo. |
| S6 | Segredo com **default hardcoded** `'cm2026admin'` | `api/news-feed/route.ts:96` | Se a env var não estiver setada, o endpoint fica aberto com senha conhecida. |
| S7 | `DATABASE_URL` com **senha em texto puro** e `PAYLOAD_SECRET` fake commitados | `Dockerfile:15-16` | Credencial de produção versionada no Git. |
| S8 | Sem rate limit, honeypot ou captcha em `/api/leads` e `/api/contact` | 2 rotas | Flood de leads falsos, custo de e-mail, poluição do funil. |
| S9 | `.env.example` desatualizado (aponta MongoDB) e não documenta as 12 variáveis realmente usadas | raiz | Deploy quebra silenciosamente; automações caem sem alarme. |
| S10 | `CookieConsent` existe mas não bloqueia efetivamente scripts antes do aceite | `components/ui/CookieConsent.tsx` | Consentimento decorativo — não cumpre LGPD art. 8º. |

---

## 5. Onde a automação para hoje

| Processo | Hoje | Falta |
|---|---|---|
| Notícias jurídicas | Cron 6/6h cria registros com `status: pending` | Ninguém aprova. A fila cresce e nada publica. Parser é regex sobre XML (frágil), dedupe só por slug, sem retenção. |
| Publicação de conteúdo | Manual no `/admin` | Nenhuma pauta, nenhuma cadência, nenhuma geração assistida |
| Lead novo | E-mail + webhook n8n opcional | Sem resposta automática ao lead, sem SLA, sem nutrição, sem dedupe por telefone |
| Prazos | Rota `/api/deadlines` envia e-mail **quando alguém chama** | Não há cron. Depende de alguém abrir a tela. |
| Processos dos clientes | Consulta DataJud sob demanda | Nenhuma sincronização diária, nenhum aviso de movimentação nova |
| NPS | Formulário manual | Sem disparo automático pós-encerramento; depoimento aprovado não vira Testimonial |
| Redes sociais | Card gerado manualmente, um a um | Sem geração automática ao publicar, sem legenda por IA, sem lote |
| Publicação no site | `force-dynamic` (sem cache) | Rota de revalidate existe e não é chamada por nenhum hook |
| Saúde do sistema | Nenhuma | Sem `/api/health`, sem log de execução, sem alerta de job quebrado |

---

## 6. Resumo do trabalho

| Frente | Esforço | Prioridade |
|---|---|---|
| A — Segurança e LGPD | 3–5 dias | **P0 — antes de tudo** |
| B — Dissolução da sociedade (dados + conteúdo) | 3–4 dias | P0 |
| C — Identidade visual e assets | 5–7 dias | P1 |
| D — CMS-first (eliminar hardcode) | 5–7 dias | P1 |
| E — Motor de automação | 10–14 dias | P2 |
| F — Dinamismo, ISR e performance | 4–6 dias | P2 |
| G — Deploy, observabilidade, testes | 3–4 dias | P3 |

Total estimado: **6 a 8 semanas** de execução por um agente com revisão humana em cada marco.
