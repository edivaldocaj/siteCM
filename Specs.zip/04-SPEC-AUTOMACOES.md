# 04 — Motor de automação e operação autônoma

Meta: o site trabalha sozinho. O Dr. Edivaldo abre o painel de manhã, vê o que aconteceu e decide — não executa tarefa operacional.

**Princípio que atravessa tudo:** automação em escritório de advocacia gera rascunho, nunca ato jurídico. Toda peça, petição, resposta a cliente ou publicação passa por aprovação humana. O sistema tira o trabalho repetitivo do caminho; não substitui juízo profissional nem responsabilidade técnica do advogado.

---

## 0. Infraestrutura comum

### 0.1 Agendador

Hoje há um cron de GitHub Actions (a cada 6h) chamando `/api/news-feed`. Frágil: falha silenciosa, sem retry, sem log, e o repositório precisa estar ativo.

**Substituir por Payload Jobs Queue** (nativo no 3.x): tarefas definidas em código, agendamento por cron, retry com backoff, log em banco, execução disparada por `/api/payload-jobs/run` protegida por `cronSecret`.

```ts
// payload.config.ts
jobs: {
  access: { run: ({ req }) => Boolean(req.user?.roles?.includes('admin')) },
  tasks: [FetchNewsTask, CurateNewsTask, SyncDatajudTask, DeadlineAlertTask,
          NpsTriggerTask, SocialAssetTask, LeadFollowUpTask, HealthCheckTask],
  autoRun: [
    { cron: '0 */4 * * *', queue: 'content'   },
    { cron: '0 10 * * *',  queue: 'processes' },  // 07h BRT
    { cron: '0 11 * * *',  queue: 'alerts'    },  // 08h BRT
    { cron: '*/15 * * * *',queue: 'leads'     },
  ],
}
```

Fallback (se o host não mantiver processo vivo): manter GitHub Actions, mas chamando `/api/payload-jobs/run` — um único endpoint, não cinco.

### 0.2 Log de execução

Toda tarefa grava em `AutomationRuns`: `task`, `startedAt`, `finishedAt`, `status` (success/partial/failed), `itemsIn`, `itemsOut`, `errorMessage`, `payload` (JSON resumido).

Uma automação que falha em silêncio é pior que automação nenhuma — cria confiança falsa.

### 0.3 Alarme

`HealthCheckTask` roda de hora em hora e verifica: banco responde, última execução de cada tarefa dentro da janela esperada, fila de leads sem item parado além do SLA, chaves de API presentes. Se algo falha → e-mail e WhatsApp para o titular. Estado visível em `/admin-tools/dashboard`.

---

## 1. Motor de conteúdo

### 1.1 Ingestão de notícias — `FetchNewsTask`

Reescrever `api/news-feed/route.ts`. Problemas atuais: parser por regex sobre XML, dedupe só por slug, sem retenção, sem relevância, segredo com default hardcoded.

**Novo comportamento:**

| Item | Especificação |
|---|---|
| Parser | `fast-xml-parser`. Regex sobre XML quebra com CDATA aninhado e entidades |
| Fontes | Conjur, Migalhas, STJ, STF, TJRN, TRF5, Google News por área. Fontes editáveis em `automation-config` |
| Dedupe | Hash SHA-1 da URL canônica em `sourceHash` (índice único). Slug não basta — títulos repetem entre fontes |
| Retenção | Notícias não publicadas somem após `newsRetentionDays` (padrão 90) |
| Rate | Máx. 1 req/s por domínio, `User-Agent` identificando o site, respeitar `robots.txt` |
| Falha | Uma fonte fora do ar não derruba o lote. Status `partial` |

### 1.2 Curadoria por IA — `CurateNewsTask`

`ANTHROPIC_API_KEY` já está no projeto (usada só no gerador de petições). Estender para curadoria.

Para cada notícia com `status: pending`:

1. **Relevância (0–100)** — quanto interessa a um cliente das áreas do escritório em Natal/RN. Retorna JSON estruturado com `score`, `area`, `justification`.
2. **Resumo autoral** — 2 a 3 frases **com palavras próprias**. Nunca copiar trechos: matéria jornalística é obra protegida. Guardar em `aiSummary`, sempre com link para a fonte e crédito visível.
3. **Roteamento**
   - `score ≥ newsAutoPublishScore` (padrão 75) → `status: published` automaticamente
   - `40 ≤ score < 75` → fila de revisão no painel, com botão de 1 clique
   - `score < 40` → descartada

O limiar é configurável no admin. Começar conservador (85) e baixar conforme a confiança.

### 1.3 Pauta editorial — `EditorialCalendar`

Nova collection: `area`, `suggestedTitle`, `angle`, `targetMonth`, `status`, `sourceNews` (relação), `assignedTo`.

Tarefa semanal:
1. Conta posts publicados por área nos últimos 90 dias.
2. Identifica áreas descobertas.
3. Cruza com as notícias de maior relevância da semana.
4. Gera 3 a 5 sugestões de pauta com ângulo — não o artigo, a pauta.

Isso resolve o problema real: o escritório não deixa de publicar por falta de ferramenta, deixa por não saber sobre o quê.

### 1.4 Rascunho de artigo

Ação manual no admin (**nunca automática**): "Gerar rascunho a partir desta pauta".

Gera post em `draft` com estrutura, fundamentação legal e sugestão de FAQ. Marca `aiAssisted: true`.

**Trava obrigatória:** post com `aiAssisted: true` não pode ir a `published` sem que um usuário com papel `admin` marque `reviewedBy` e `reviewedAt`. Validação no `beforeChange`. Conteúdo jurídico publicado sob a marca do escritório é responsabilidade profissional do advogado — a trava existe para que isso não dependa de disciplina.

---

## 2. Motor de captação

### 2.1 Entrada de lead

Fluxo atual: `POST /api/leads` → score → cria registro → e-mail → webhook n8n opcional. Bom começo. Falta o essencial.

**Adicionar, em ordem:**

1. **Rate limit** — 5 envios por IP a cada 10 min. Sem isso, um bot enche a base.
2. **Honeypot + timing** — campo invisível preenchido = descarta; formulário respondido em menos de 3s = descarta.
3. **Consentimento LGPD** — checkbox obrigatório, com registro de `consentText`, `consentedAt`, `ip`, `userAgent`. Sem isso não há base legal para tratar o dado.
4. **Dedupe por telefone normalizado** — mesmo telefone em 30 dias vira nota no lead existente, não registro novo.
5. **Classificação por IA** — área provável, urgência, complexidade, viabilidade preliminar, resumo em uma linha. Grava em `aiTriage`. **Não decide nada** — enriquece a fila.
6. **Resposta automática ao lead** (se `leadAutoReply` ligado) — WhatsApp em até 60s: confirmação de recebimento, prazo de retorno, canal de urgência. Texto sem promessa de resultado.
7. **SLA** — status `new` além de `leadSlaHours` (padrão 4h úteis) dispara lembrete; o dobro escala para o e-mail de escalonamento.
8. **Nutrição** — lead sem resposta em D+1, D+3, D+7 recebe conteúdo útil da área (artigo, não venda). Para ao primeiro sinal de resposta.

### 2.2 Contrato do webhook n8n

`N8N_WEBHOOK_URL` já existe, sem contrato documentado. Formalizar:

```json
{
  "event": "lead.created",
  "version": "1",
  "timestamp": "2026-08-09T14:22:10Z",
  "signature": "sha256=...",
  "data": {
    "id": 1234, "name": "...", "phone": "+5584...", "email": "...",
    "source": "campaign-form", "campaignSlug": "fraudes-bancarias",
    "score": 78, "urgency": "high",
    "aiTriage": { "area": "consumidor", "viability": "alta", "summary": "..." },
    "utm": { "source": "instagram", "medium": "cpc", "campaign": "..." },
    "adminUrl": "https://.../admin/collections/leads/1234"
  }
}
```

Assinar com HMAC. Eventos previstos: `lead.created`, `lead.status_changed`, `deadline.approaching`, `process.moved`, `nps.received`, `automation.failed`.

### 2.3 Painel do funil

Evoluir o kanban existente: filtro por área/origem/score, arrastar muda status com registro em `AuditLog`, tempo em cada etapa, taxa de conversão por campanha, alerta visual de SLA estourado, ação em massa.

---

## 3. Motor processual — o maior ganho não explorado

`src/lib/datajud.ts` integra a API pública do CNJ, mas só sob demanda quando o cliente digita o CPF. O dado está disponível todo dia e ninguém olha.

### `SyncDatajudTask` (diária, 07h)

```
Para cada Client ativo:
  Para cada processo cadastrado:
    Consulta DataJud
    Compara movimentos com o snapshot local
    Se há movimento novo:
      → grava em ProcessMovements
      → classifica por IA: informativo | exige ação | prazo aberto
      → se "prazo aberto": cria rascunho em Deadlines com sugestão de data
      → notifica o advogado responsável (WhatsApp + e-mail)
      → se o movimento for público e relevante ao cliente,
        notifica o cliente em linguagem simples
```

Nova collection `ProcessMovements`: `client`, `processNumber`, `court`, `movementDate`, `rawDescription`, `plainDescription` (versão traduzida por IA), `classification`, `notifiedClient`, `notifiedAttorney`.

**Cuidados obrigatórios:**
- Processos em segredo de justiça: **nunca** sincronizar nem notificar. Checar a flag do DataJud antes de qualquer gravação.
- A tradução para linguagem simples é conveniência, não orientação jurídica. Toda notificação ao cliente termina com: *"Este é um aviso automático de movimentação. Fale com seu advogado antes de tomar qualquer decisão."*
- Prazo criado automaticamente entra como **rascunho** com aviso de conferência. Prazo processual errado gera responsabilidade civil do advogado. O sistema sugere; quem confirma é o profissional.

Isso transforma o portal do cliente de "consulta que ele faz" em "aviso que ele recebe" — a mudança de percepção mais forte de todo o projeto.

---

## 4. Motor de prazos

`api/deadlines/route.ts` já monta e envia o e-mail. Só falta alguém chamar.

`DeadlineAlertTask` (diária, 08h):
- Alerta em D-7, D-3, D-1 e D-0 (configurável)
- Canais: e-mail + WhatsApp
- Digest matinal único com tudo do dia, em vez de e-mail por prazo
- Prazo vencido sem baixa → escala no dia seguinte
- Prazo criado pelo `SyncDatajudTask` vem marcado `sourceAuto: true` e destacado no painel até conferência

Trocar o roteamento por e-mail hardcoded (`attorneyEmails` em `api/deadlines/route.ts:6-8`) pelo `email` do registro em `Team`.

---

## 5. Motor de relacionamento

### 5.1 NPS automático

Hoje o formulário existe e alguém precisa enviar o link.

`NpsTriggerTask`: cliente com caso encerrado há `npsTriggerDays` (padrão 30) e sem resposta registrada recebe convite por WhatsApp com link tokenizado de uso único.

### 5.2 Depoimento → site

Resposta NPS com nota ≥ 9 e comentário → cria `Testimonial` em rascunho e envia ao cliente um pedido explícito de autorização de publicação (com opção de anonimato). **Só publica com aceite registrado** (`consentAt`, `consentIp`). Depoimento de cliente sem autorização expressa é problema de LGPD e de sigilo profissional ao mesmo tempo.

### 5.3 Portal do cliente

- Login por token de uso único enviado por WhatsApp, com expiração — substitui o `accessToken` permanente atual (ver spec 05)
- Linha do tempo do processo em linguagem simples
- Documentos com upload dos dois lados
- Preferência de notificação (WhatsApp / e-mail / nenhuma)
- Botão "falar com meu advogado" que já abre o WhatsApp com o contexto do processo

---

## 6. Motor de marketing

### 6.1 Geração automática de peças

`SocialAssetTask` dispara quando um Post ou Campaign é publicado:

1. Renderiza **feed 1080×1080** e **story 1080×1920** com a marca nova (o `Media` já tem esses tamanhos configurados)
2. Gera **legenda** por IA (tom informativo, sem promessa de resultado, com CTA para o link)
3. Sugere **hashtags** por área
4. Gera **OG 1200×630**
5. Salva tudo em `Media`, vinculado ao conteúdo
6. Notifica: "3 peças prontas para o post X"

Migrar a renderização de canvas no browser (`admin-tools/cards`) para `@vercel/og` / Satori no servidor: fontes carregam de forma confiável, o resultado é idêntico toda vez, e passa a funcionar sem alguém abrir a tela.

### 6.2 Publicação (fase 2)

Integração com Instagram Graph API para agendar. Requer conta Business, app Meta aprovado e revisão. **Não é fase 1.** Enquanto isso, o pacote gerado é baixado em ZIP e postado manualmente — ainda economiza a maior parte do trabalho.

### 6.3 Atribuição

`CampaignEvents` já registra eventos. Fechar o ciclo: `utm` do lead → status → caso fechado. Painel mostrando custo por lead e por caso, por campanha. Sem isso, decidir onde investir é chute.

---

## 7. Painel de automações

Nova tela em `/admin-tools/automacoes`:

```
┌──────────────────────────────────────────────────────────────┐
│  ▌▌▌  AUTOMAÇÕES                                             │
│                                                              │
│  Notícias        ● ativa   última 04:00   12 lidas · 3 pub.  │
│  Curadoria IA    ● ativa   última 04:06   3 aprovadas        │
│  DataJud         ● ativa   última 07:00   41 proc. · 2 mov.  │
│  Prazos          ● ativa   última 08:00   4 alertas          │
│  Leads / SLA     ● ativa   há 6 min       1 fora do SLA ⚠    │
│  NPS             ○ pausada                                   │
│  Redes sociais   ● ativa   última 11:20   6 peças            │
│                                                              │
│  [ Executar agora ]  [ Ver histórico ]  [ Configurar ]       │
└──────────────────────────────────────────────────────────────┘
```

Cada linha: liga/desliga, execução manual, últimos 20 registros, último erro.

---

## 8. Variáveis de ambiente

`.env.example` está desatualizado (aponta MongoDB). Reescrever:

```bash
# Banco e app
DATABASE_URL=postgres://user:senha@host:5432/cavalcantealbuquerque
PAYLOAD_SECRET=                      # 32+ caracteres aleatórios
NEXT_PUBLIC_SITE_URL=https://cavalcantealbuquerque.com.br

# Contato
NEXT_PUBLIC_WHATSAPP_NUMBER=5584991243985
NEXT_PUBLIC_WHATSAPP_MESSAGE=Olá! Gostaria de falar com um advogado.
CONTACT_EMAIL=contato@cavalcantealbuquerque.com.br

# E-mail (domínio verificado — não usar onboarding@resend.dev)
RESEND_API_KEY=
RESEND_FROM="Cavalcante Albuquerque <nao-responda@cavalcantealbuquerque.com.br>"

# IA
ANTHROPIC_API_KEY=

# Processos
DATAJUD_API_KEY=

# Automação — um segredo POR finalidade, nunca compartilhado
CRON_SECRET=
REVALIDATE_SECRET=
N8N_WEBHOOK_URL=
N8N_WEBHOOK_SECRET=

# WhatsApp (escolher um)
WHATSAPP_PROVIDER=                   # meta | evolution
WHATSAPP_TOKEN=
WHATSAPP_PHONE_ID=

# Observabilidade
SENTRY_DSN=
```

---

## 9. Ordem de implementação

| Onda | Entrega | Por quê primeiro |
|---|---|---|
| 1 | Jobs Queue + AutomationRuns + HealthCheck + `.env` | Nada mais funciona de forma confiável sem isso |
| 2 | Revalidate por hook + ISR | Ganho imediato de performance, custo baixo |
| 3 | DeadlineAlertTask | Rota já pronta; é só agendar. Maior valor por hora investida |
| 4 | Leads: rate limit, consentimento, dedupe, SLA, resposta automática | Protege o funil e cumpre LGPD |
| 5 | FetchNews v2 + CurateNews | Destrava a fila de notícias parada |
| 6 | SyncDatajud + ProcessMovements | Maior valor percebido pelo cliente |
| 7 | NPS + depoimento com consentimento | Alimenta prova social de forma legítima |
| 8 | SocialAssetTask | Economiza horas de produção |
| 9 | Pauta editorial + rascunho assistido | Resolve a constância de publicação |
| 10 | Publicação em redes (Meta API) | Depende de aprovação externa |
