# 06 — Dinamismo, performance e experiência

Pedido: "página ainda mais dinâmica". Dinamismo aqui tem três sentidos, e os três importam:
**(1)** o conteúdo muda sozinho, **(2)** a página responde a quem está olhando, **(3)** a interface tem vida sem virar carrossel de efeitos.

---

## 1. Publicação instantânea — o ganho mais barato do projeto

### Situação
`page.tsx:15` → `export const dynamic = 'force-dynamic'`. Cada visita dispara 7 queries. Sem cache, sem CDN. E `/api/revalidate` está escrita, correta, e **nunca é chamada**.

### Correção

**a) Trocar renderização por ISR com tags**

```ts
// (frontend)/page.tsx
export const revalidate = 300
// remover: export const dynamic = 'force-dynamic'

const posts = await payload.find({ collection: 'posts', /* ... */ })
// envolver as buscas em unstable_cache com tags: 'posts', 'campaigns', 'site-config'...
```

**b) Hook `afterChange` em toda collection publicável**

```ts
// src/hooks/revalidate.ts
export const revalidateAfterChange =
  (tags: string[], pathFn?: (doc) => string[]) =>
  async ({ doc, req, context }) => {
    if (context?.skipRevalidate) return doc
    await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/api/revalidate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        secret: process.env.REVALIDATE_SECRET,
        tags,
        paths: pathFn ? pathFn(doc) : [],
      }),
    }).catch((e) => req.payload.logger.error(`revalidate falhou: ${e}`))
    return doc
  }
```

Aplicar em: Posts, Campaigns, NewsArticles, PracticeAreas, Testimonials, Team, Faqs, e nos globals `site-config`, `homepage`, `brand-config`, `navigation`. Adicionar `afterDelete` também — despublicar precisa refletir na hora.

Estender `/api/revalidate` para aceitar `tags[]` além de `paths[]`.

**Resultado:** página servida de cache (TTFB abaixo de 100ms) e atualizada em segundos quando o Dr. Edivaldo salva algo. Hoje é o oposto: lenta sempre e sem controle de cache.

---

## 2. Conteúdo que se move sozinho

Com o motor da spec 04, a home passa a mudar sem ninguém mexer:

| Seção | O que muda sozinho |
|---|---|
| Notícias | Curadoria por IA publica de 4 em 4 horas |
| Campanhas | Entram e saem por janela de data (`startsAt` / `endsAt`) |
| Blog | Pauta sugerida semanalmente; rascunho assistido |
| Depoimentos | Entram via NPS com consentimento |
| Faixa de urgência | Aparece só na janela configurada |
| TrustBar | Números calculados do banco (anos de atuação, áreas ativas, tempo médio de resposta) em vez de digitados |

---

## 3. Página que responde a quem está olhando

Personalização leve, sem rastreamento invasivo e sem quebrar o cache.

### 3.1 Continuidade de campanha

Visitante que chega com `?utm_campaign=fraudes-bancarias`: o hero da home passa a mostrar variante ligada àquela campanha, e o formulário de contato já vem com a área preenchida.

Implementar por **cookie de primeira parte** lido em Server Component, com variantes pré-renderizadas — não por JavaScript no cliente (que causa flash de conteúdo e piora o LCP).

### 3.2 Faixa contextual por horário

Fora do horário comercial, a faixa muda: *"Estamos fora do horário de atendimento. Para urgência criminal, ligue para o plantão."* Horário vindo de `brand-config.businessHours`. Renderizado no servidor, com fuso `America/Fortaleza` fixo.

### 3.3 Agenda real

O botão "Agendar Consulta" hoje leva para `/contato`. Integrar Cal.com (self-hosted ou nuvem) ou Google Calendar: mostrar horários livres reais e confirmar por WhatsApp. É a diferença entre "mande uma mensagem e espere" e "escolha quinta às 15h".

### 3.4 Progresso de leitura no blog

Barra de 2px no topo, preenchida com o gradiente de aço — o elemento assinatura fazendo trabalho de verdade.

---

## 4. Onde a interface pode ter vida

`framer-motion` está instalado e praticamente não é usado. Ou remove (menos 40KB) ou usa direito. Recomendo usar, com disciplina:

| Momento | Comportamento |
|---|---|
| Hero | Eyebrow → título → subtítulo → CTAs, escalonados 60ms |
| Régua de seção | As três barras crescem da base ao entrar no viewport |
| Cards | Varredura de aço na borda superior no hover/foco |
| TrustBar | Números interpolam até o valor, uma única vez |
| Menu mobile | Slide + fade, com focus trap e fechamento por `Esc` |

Tudo dentro de `@media (prefers-reduced-motion: no-preference)`. Nada de parallax, nada de loop ambiente, nada de partícula.

---

## 5. Performance

### Metas
```
LCP     ≤ 1.8s (4G)
INP     ≤ 150ms
CLS     ≤ 0.05
Lighthouse ≥ 95 nas quatro categorias
JS inicial ≤ 140KB gzip
```

### Ações

1. **Fontes via `next/font`** — hoje há `<link>` para `fonts.googleapis.com` com duas conexões extras e sem `font-display` controlado. Migrar para `next/font/google` com `display: 'swap'` e subset latino.
2. **Menos `'use client'`** — `Header`, `Footer`, `TestimonialsCarousel`, `AreasPageClient`, `AboutPageClient` e `ContatoPageClient` são client components inteiros. Vários só precisam de interatividade em uma parte. Separar em Server Component com uma ilha cliente.
3. **`next/image` em todo lugar** — com `sizes` correto e `priority` só no hero.
4. **Ícones sob demanda** — `lucide-react` importado direto por ícone, nunca o pacote.
5. **Rotas pesadas por `dynamic()`** — `calculadora` (482 linhas), `admin-tools/cards` (413), `CampaignLeadForm` (626) não precisam estar no bundle inicial.
6. **Preconnect** só para o que realmente se usa.
7. **Cabeçalhos de cache** para `/brand/*` e `/media/*`: `immutable, max-age=31536000`.

---

## 6. Acessibilidade

O padrão atual — hover via `onMouseEnter` mudando `style` inline — não funciona por teclado. É o problema de acessibilidade mais espalhado do projeto.

```
[ ] Todo hover tem :focus-visible equivalente
[ ] Contraste AA em texto e componentes de interface
[ ] Menu mobile com aria-expanded, aria-controls, focus trap e Esc
[ ] Carrossel de depoimentos navegável por teclado, com pausa
[ ] Formulários com <label> real, aria-describedby no erro, aria-live no envio
[ ] Hierarquia de heading correta (um h1 por página)
[ ] Skip link para o conteúdo principal
[ ] Toda imagem com alt significativo; decorativa com alt=""
[ ] Vídeo de campanha com legenda
[ ] Teste real com leitor de tela em Chrome e Safari
```

Acessibilidade em site de escritório de advocacia tem peso extra: parte do público chega com deficiência, idade avançada ou em situação de vulnerabilidade — é literalmente o público de várias das áreas de atuação.

---

## 7. Novas páginas

| Rota | Por quê |
|---|---|
| `/privacidade` | Obrigatório (LGPD) |
| `/termos` | Termos de uso |
| `/faq` | SEO + rich snippet `FAQPage` |
| `/equipe/[slug]` | Perfil individual — reforça a pessoa do Dr. Edivaldo, que agora é a marca |
| `/obrigado` | Confirmação pós-formulário, com conversão rastreável |
| `not-found.tsx` | Hoje usa o 404 padrão do Next |
| `error.tsx` | Erro tratado com a marca, sem stack trace |
| `loading.tsx` | Skeleton nas rotas dinâmicas |

---

## 8. Estrutura da home depois

```
┌─────────────────────────────────────────────────────┐
│ HEADER  lockup claro · nav do CMS · CTA WhatsApp    │
├─────────────────────────────────────────────────────┤
│ HERO                                                │
│   ▌▌▌ ADVOCACIA EM NATAL/RN                         │
│   Advocacia com                                     │
│   estratégia e solidez.        ← Cormorant + aço    │
│   [ Falar com o escritório ]  [ Agendar consulta ]  │
│   fundo: navy-950 + watermark 3%                    │
├─────────────────────────────────────────────────────┤
│ TRUST BAR   números do banco, sem promessa          │
├─────────────────────────────────────────────────────┤
│ ÁREAS DE ATUAÇÃO   cards com varredura de aço       │
├─────────────────────────────────────────────────────┤
│ PLANTÃO CRIMINAL   faixa --ca-urgent, por janela    │
├─────────────────────────────────────────────────────┤
│ QUEM CONDUZ O SEU CASO   Dr. Edivaldo, foto + bio   │
├─────────────────────────────────────────────────────┤
│ CAMPANHAS ATIVAS   entram e saem por data           │
├─────────────────────────────────────────────────────┤
│ DEPOIMENTOS   com consentimento registrado          │
├─────────────────────────────────────────────────────┤
│ NOTÍCIAS   curadoria automática 4/4h                │
├─────────────────────────────────────────────────────┤
│ ARTIGOS                                             │
├─────────────────────────────────────────────────────┤
│ FAQ   NOVO — SEO + FAQPage schema                   │
├─────────────────────────────────────────────────────┤
│ CONTATO   form + mapa + horário contextual          │
├─────────────────────────────────────────────────────┤
│ FOOTER   4 colunas do CMS · OAB · CNPJ · LGPD       │
└─────────────────────────────────────────────────────┘
```

Cada bloco ativável, ordenável e datável pelo admin (spec 03, B2).
