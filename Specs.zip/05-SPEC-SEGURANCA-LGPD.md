# 05 — Segurança, LGPD e conformidade

**Esta é a primeira frente a executar.** Os itens S1–S3 expõem dados pessoais de clientes de um escritório de advocacia. Rebranding sobre uma base insegura só aumenta o alcance do problema.

---

## 1. Controle de acesso

### 1.1 O estado atual

Seis collections estão com CRUD público:

```ts
access: { read: () => true, create: () => true, update: () => true, delete: () => true }
```

Em **Leads, ClientDocuments, Deadlines, NpsResponses, CampaignEvents, Jurisprudence**.

Como o Payload expõe REST automaticamente, isso significa que qualquer pessoa na internet consegue hoje:

```
GET    /api/leads          → baixar toda a base de leads (nome, telefone, CPF, descrição do caso)
GET    /api/client-documents → listar documentos de clientes
DELETE /api/leads/123      → apagar registros
PATCH  /api/globals/site-config → reescrever o site inteiro
```

Não é hipótese: são as regras que estão no código.

### 1.2 Papéis

```ts
// Users.roles — hasMany, saveToJWT: true
'admin'   // Dr. Edivaldo — tudo
'editor'  // conteúdo: posts, campanhas, notícias, mídia
'staff'   // operação: leads, prazos, clientes; não configura nem apaga
'client'  // portal do cliente; só os próprios dados
```

### 1.3 Funções de acesso

Criar `src/access/` (a pasta é prevista no `AGENTS.md` e não existe):

```ts
export const anyone: Access = () => true
export const authenticated: Access = ({ req: { user } }) => Boolean(user)
export const adminOnly: Access = ({ req: { user } }) => !!user?.roles?.includes('admin')
export const adminOrEditor: Access = ({ req: { user } }) =>
  !!user?.roles?.some(r => ['admin','editor'].includes(r))
export const adminOrStaff: Access = ({ req: { user } }) =>
  !!user?.roles?.some(r => ['admin','staff'].includes(r))
export const publishedOnly: Access = ({ req: { user } }) =>
  user ? true : { status: { equals: 'published' } }
export const ownClientData: Access = ({ req: { user } }) => {
  if (!user) return false
  if (user.roles?.includes('admin') || user.roles?.includes('staff')) return true
  return { client: { equals: user.id } }
}
```

### 1.4 Matriz obrigatória

| Collection | read | create | update | delete |
|---|---|---|---|---|
| Users | adminOnly | adminOnly | adminOrSelf | adminOnly |
| Media | anyone | adminOrEditor | adminOrEditor | adminOnly |
| Pages | publishedOnly | adminOrEditor | adminOrEditor | adminOnly |
| Posts | publishedOnly | adminOrEditor | adminOrEditor | adminOnly |
| Campaigns | publishedOnly | adminOrEditor | adminOrEditor | adminOnly |
| Testimonials | `{ approved: true }` p/ público | adminOrEditor | adminOrEditor | adminOnly |
| PracticeAreas | anyone | adminOrEditor | adminOrEditor | adminOnly |
| NewsArticles | publishedOnly | adminOrEditor **+ system** | adminOrEditor | adminOnly |
| Team | `{ showOnSite: true }` p/ público | adminOnly | adminOnly | adminOnly |
| Faqs | anyone | adminOrEditor | adminOrEditor | adminOnly |
| **Leads** | **adminOrStaff** | **anyone*** | **adminOrStaff** | **adminOnly** |
| **Clients** | **adminOrStaff** | adminOrStaff | adminOrStaff | adminOnly |
| **ClientDocuments** | **ownClientData** | adminOrStaff | adminOrStaff | adminOnly |
| **Deadlines** | **adminOrStaff** | adminOrStaff | adminOrStaff | adminOnly |
| **NpsResponses** | **adminOrStaff** | anyone* | adminOrStaff | adminOnly |
| **CampaignEvents** | **adminOrStaff** | anyone* | adminOnly | adminOnly |
| Jurisprudence | authenticated | adminOrEditor | adminOrEditor | adminOnly |
| AutomationRuns | adminOnly | system | system | adminOnly |
| AuditLog | adminOnly | system | never | never |

\* `create: anyone` existe porque o formulário público precisa gravar. Mas **nunca direto pela REST do Payload**: desabilitar o endpoint REST nessas collections e deixar a criação apenas pela rota de API própria, que valida, aplica rate limit e usa `overrideAccess` de forma controlada.

```ts
// nas collections com create público
endpoints: false,          // sem REST automática
graphQL: false,
```

### 1.5 Globals

`site-config`, `homepage`, `brand-config`, `navigation`, `automation-config`:
```ts
access: { read: () => true, update: adminOnly }
```

### 1.6 Campos sensíveis

```ts
// Clients.accessTokenHash
access: { read: adminOnly, update: adminOnly }
// Leads.cpf
access: { read: adminOrStaff }
// Users.roles
access: { update: adminOnly }
```

---

## 2. Autenticação

### 2.1 Painel interno `/admin-tools`

Hoje: `useState` no cliente + um bearer compartilhado. O gate é visual — não protege nada.

**Substituir por sessão real do Payload:**
- Middleware Next.js valida o cookie de sessão nas rotas `/admin-tools/*`
- Sem sessão válida → redireciona para `/admin/login`
- Rotas de API internas verificam `req.user` e papel, não bearer
- **Apagar** `AdminAuthContext` e `AdminLoginGate`

Alternativa: eliminar `/admin-tools` e reconstruir as telas como *custom views* dentro do painel do Payload. Menos superfície de ataque, uma autenticação só, e o admin já é responsivo. Recomendo esta.

### 2.2 Portal do cliente

Hoje: `accessToken` em texto, permanente, campo com `read` público.

**Novo fluxo:**
1. Cliente informa CPF em `/cliente`
2. Se existir e estiver ativo, o sistema envia um **código de 6 dígitos por WhatsApp** para o telefone cadastrado
3. Código válido por 10 min, uso único, máximo 3 tentativas
4. Acerto cria sessão de 24h (cookie `httpOnly`, `secure`, `sameSite=lax`)
5. Guardar `accessTokenHash` (bcrypt), nunca o valor
6. Registrar cada acesso em `AuditLog`

Isso elimina a enumeração de tokens e cria trilha de auditoria — que é exatamente o que se cobra de quem guarda dado de processo.

### 2.3 Segredos

- Um segredo por finalidade: `CRON_SECRET`, `REVALIDATE_SECRET`, `N8N_WEBHOOK_SECRET`
- **Remover todos os defaults hardcoded.** Se a variável faltar, a rota responde 503 — nunca abre com senha conhecida (`api/news-feed/route.ts:96` tem `'cm2026admin'` como fallback)
- Comparação com `crypto.timingSafeEqual`, não `!==`
- Rotacionar todos os segredos existentes no rebranding — eles circularam em texto

---

## 3. Infraestrutura

### 3.1 Dockerfile

Remover as linhas 15–16 (`DATABASE_URL` com senha real e `PAYLOAD_SECRET` fake). Usar `ARG` só para o build, com valores descartáveis, e injetar os reais em runtime.

Depois disso: **a senha do Postgres precisa ser rotacionada**, porque está no histórico do Git. Rotacionar sem limpar o histórico não resolve — considerar `git filter-repo` se o repositório for público.

### 3.2 Cabeçalhos HTTP

`next.config.ts`:
```
Content-Security-Policy         (começar em report-only)
Strict-Transport-Security       max-age=63072000; includeSubDomains; preload
X-Content-Type-Options          nosniff
X-Frame-Options                 SAMEORIGIN
Referrer-Policy                 strict-origin-when-cross-origin
Permissions-Policy              camera=(), microphone=(), geolocation=()
```

### 3.3 Rate limit

`/api/leads`, `/api/contact`, `/api/nps`, `/api/datajud`, login do portal.
5 req / 10 min por IP. Upstash Redis ou tabela no Postgres. Resposta 429 com mensagem clara.

### 3.4 Limpeza

```
src/app/my-route/route.ts        apagar
docker-compose.yml               reescrever (sobe MongoDB; o projeto usa Postgres)
.github/workflows/deploy.yml     unificar com a estratégia Docker do README
```

---

## 4. LGPD

### 4.1 Base legal

| Dado | Finalidade | Base legal |
|---|---|---|
| Lead (nome, telefone, e-mail, descrição do caso) | Contato e análise preliminar | Consentimento (art. 7º, I) — checkbox obrigatório e registrado |
| Cliente (CPF, processos, documentos) | Execução do contrato de honorários | Execução de contrato (art. 7º, V) |
| Cookies analíticos | Medição | Consentimento — só após aceite |
| Cookies essenciais | Funcionamento | Legítimo interesse |

### 4.2 Implementação

1. **Consentimento no formulário** — checkbox não pré-marcado, com o texto exato armazenado junto de data, IP e user-agent. Guardar o texto, não só o `true`: a política muda, a prova precisa ser do que a pessoa leu.
2. **Cookie consent com bloqueio real** — nenhum script de terceiro carrega antes do aceite. O componente atual exibe o banner mas não bloqueia. Categorias: essenciais (sempre), analíticos, marketing.
3. **Política de Privacidade** em `/privacidade`, editável no CMS, com: dados coletados, finalidade, base legal, compartilhamento (Resend, Anthropic, CNJ, n8n), prazo de retenção, direitos do titular, contato do Encarregado.
4. **Encarregado (art. 41)** — nome e e-mail publicados no rodapé.
5. **Direitos do titular** — canal em `/privacidade` para acesso, correção, exclusão e portabilidade. Prazo de resposta de 15 dias.
6. **Retenção** — lead sem conversão apagado ou anonimizado após 24 meses. Job automático.
7. **Registro de operações** — `AuditLog` para leitura e alteração de dado pessoal.
8. **Transferência internacional** — Anthropic e Resend processam fora do Brasil. Declarar na política.
9. **Minimização** — CPF no formulário público de lead é excessivo antes da contratação. Recomendo remover do formulário de campanha e coletar só na contratação.

> **Sigilo profissional:** dado de cliente de advocacia não é só dado pessoal — é informação protegida por sigilo (EOAB art. 34, VII). Enviar descrição de caso para API de IA de terceiro merece atenção específica: pseudonimizar antes de enviar (remover nomes, CPF, número de processo) e registrar no contrato de honorários que ferramentas de apoio são utilizadas. Este ponto merece validação do próprio Dr. Edivaldo antes de ativar a triagem por IA sobre texto de caso.

---

## 5. Conformidade OAB — Provimento 205/2021

O site é publicidade profissional e está sujeito ao Código de Ética e ao Provimento 205/2021 do CFOAB.

**Vedado:**
- Prometer ou garantir resultado
- Divulgar valores obtidos, "vitórias", percentual de êxito
- Mercantilizar: "promoção", "desconto", "consulta grátis" como isca
- Captação de clientela (angariar, mesmo que indiretamente)
- Depoimento que sugira resultado garantido
- Divulgar caso concreto identificável

**Impacto direto no que existe hoje:**

| Item | Situação | Ação |
|---|---|---|
| TrustBar com estatísticas | Depende do que os números dizem. "Casos ganhos" ou "R$ recuperados" → vedado | Trocar por dados neutros: anos de atuação, áreas, tempo médio de resposta |
| Campanhas com countdown e urgência | Urgência artificial tende a mercantilização | Revisar copy: informar prazo legal real (prescrição, decadência) é legítimo; "restam 3 dias" inventado não é |
| Calculadora de indenização | Risco alto se apresentar valor como expectativa | Manter, com aviso claro: estimativa referencial, não parecer, não promessa |
| Depoimentos | Precisam de autorização e não podem sugerir resultado garantido | Consentimento + curadoria do texto |
| Gerador de cards | Legenda por IA pode gerar copy vedada | Regra no prompt + revisão humana obrigatória |
| Blog | Conteúdo informativo é permitido e recomendável | Manter |

Adicionar no rodapé, vindo do `brand-config`: identificação completa (nome, OAB/RN, endereço) e aviso de que o conteúdo é informativo e não substitui consulta.

**Recomendação:** submeter o site à Comissão de Fiscalização da OAB/RN antes do lançamento. É consulta gratuita e evita retrabalho.

---

## 6. Aceite

```
[ ] Nenhuma collection com access: () => true em create/update/delete
[ ] GET público a /api/leads e /api/client-documents retorna 403
[ ] Globals com update: adminOnly
[ ] /admin-tools protegido por middleware de sessão (ou migrado para o Payload)
[ ] Portal do cliente com código por WhatsApp e sessão expirável
[ ] Nenhum segredo com valor default no código
[ ] Segredos rotacionados após o rebranding
[ ] Dockerfile sem credencial; senha do Postgres rotacionada
[ ] Rate limit ativo nas 5 rotas públicas
[ ] Cabeçalhos de segurança presentes
[ ] Consentimento LGPD registrado com texto, data, IP e user-agent
[ ] Cookie consent bloqueando scripts antes do aceite
[ ] Política de Privacidade publicada; Encarregado identificado
[ ] Copy revisada quanto ao Provimento 205/2021
[ ] Dado enviado à IA pseudonimizado
[ ] my-route e docker-compose corrigidos
```
