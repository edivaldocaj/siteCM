# 02 — Especificação de execução do rebranding

Escopo: substituir integralmente a identidade Cavalcante & Melo por Cavalcante Albuquerque no código, nos assets e nos metadados.

**Regra de ouro:** ao terminar, os comandos abaixo devem retornar **zero resultados**.

```bash
grep -rniE "cavalcante ?& ?melo|cavalcante e melo|cavalcantemelo|gabrielly|melo|c4a96a|ede1c3|152138|logo-cm|\"CM\"" \
  --include="*.ts" --include="*.tsx" --include="*.css" --include="*.scss" \
  --include="*.json" --include="*.yml" --include="*.md" src/ public/ .github/ README.md
```

---

## R1 · Dados institucionais canônicos

Fonte única. Todo lugar que precisar desses dados lê do global `brand-config` (ver `03-SPEC-DADOS-CMS.md`), nunca de literal.

| Campo | Valor | Status |
|---|---|---|
| Nome fantasia | Cavalcante Albuquerque | definido |
| Descritor | Advocacia e Consultoria | definido |
| Razão social | *(confirmar no contrato social)* | **⚠ pendente** |
| CNPJ | *(confirmar)* | **⚠ pendente** |
| Registro OAB/RN da sociedade | *(confirmar — novo registro após dissolução)* | **⚠ pendente** |
| Tagline | Advocacia com estratégia e solidez. | definido |
| Domínio | `cavalcantealbuquerque.com.br` | confirmado (consta em `marca_2.png`) |
| E-mail | `contato@cavalcantealbuquerque.com.br` | a provisionar |
| WhatsApp | `5584991243985` | herdado — **confirmar se continua com o Dr. Edivaldo** |
| Endereço | Rua Francisco Maia Sobrinho, 1950 — Lagoa Nova, Natal/RN, 59062-250 | herdado — **confirmar se o escritório permanece no mesmo endereço após a dissolução** |
| Titular | Dr. Edivaldo Cavalcante Albuquerque *(confirmar grafia completa e nº OAB)* | **⚠ pendente** |

> Os cinco itens marcados são bloqueadores jurídicos. O agente deve criar os campos e deixá-los com valor `"__PENDENTE__"` visível no admin, não inventar dados. Publicar CNPJ ou número de OAB errado em site de advocacia é infração.

---

## R2 · Assets

### R2.1 Pipeline de preparação

Criar `public/brand/` e produzir:

| Arquivo | Origem | Especificação |
|---|---|---|
| `lockup-light.svg` | vetorizar `logmarca.png` | Letreiro claro + símbolo. Fallback: `lockup-light.png` (alpha, 2508×627) e `.webp` |
| `lockup-dark.svg` | vetorizar `logomarca_branca.png` | Letreiro navy. Fallback `.png`/`.webp` |
| `symbol.svg` | `assets/ca-symbol.svg` deste pacote | Já pronto para produção |
| `symbol-mono-light.svg` | derivar | Barras em `#EEF1F4` chapado — para tamanhos ≤32px, onde o gradiente vira ruído |
| `symbol-mono-dark.svg` | derivar | Barras em `#011536` chapado |
| `icon-round.png` | recortar de `log.png` | 1024×1024, alpha — avatar de redes sociais |
| `icon-square.png` | recortar de `log.png` | 1024×1024, alpha |
| `pattern-watermark.png` | recortar tile de `marca.png` | Unidade que repete sem emenda. Testar com `background-repeat` |
| `og-default.jpg` | recorte central de `marca_1.png` | 1200×630, qualidade 82 |
| `cover-contato.jpg` | `marca_2.png` | 1600×900 + versão 1200×630 para OG da rota |
| `cover-areas.jpg` | `areas_atuacao.png` | 1600×900 + versão 1200×630 |

### R2.2 Ícones da aplicação (Next.js App Router)

Colocar em `src/app/`:

```
src/app/favicon.ico          ← 16+32+48 multi-resolução, de symbol-mono-dark
src/app/icon.svg             ← symbol.svg
src/app/apple-icon.png       ← 180×180, de logo111.png (fundo navy, sem transparência)
src/app/opengraph-image.jpg  ← og-default.jpg (1200×630)
src/app/twitter-image.jpg    ← mesmo arquivo
public/manifest.webmanifest  ← name, short_name "Cavalcante Albuquerque",
                                theme_color "#011536", background_color "#F8F6F4",
                                icons 192 / 512 / 512-maskable
```

### R2.3 Remoções

```
public/images/logo-cm.png        ← apagar (não é referenciado por nenhum componente)
src/app/(frontend)/styles.css    ← apagar e remover o import de layout.tsx:2
src/app/my-route/route.ts        ← apagar (boilerplate do template)
```

---

## R3 · Substituições no código

### R3.1 Tokens (faça primeiro — desbloqueia o resto)

1. Substituir todo o conteúdo de `src/styles/globals.css` por `assets/tokens.css` deste pacote.
2. Varrer literais hexadecimais e trocar por `var(--color-ca-*)`:

| Antigo | Novo | Ocorrências aprox. |
|---|---|---|
| `#c4a96a`, `rgba(196,169,106,*)` | `var(--color-ca-steel-500)` / `--ca-gradient-steel` | 47 |
| `#ede1c3` | `var(--color-ca-platinum-100)` | 4 |
| `#152138` | `var(--color-ca-navy-950)` | 22 |
| `#1c2d4a` | `var(--color-ca-navy-800)` | 6 |
| `#0e1628` | `var(--color-ca-navy-900)` | 4 |
| `#b8bfc8`, `rgba(184,191,200,*)` | `var(--color-ca-steel-400)` com opacidade via `color-mix()` | 38 |
| `#d4d8de` | `var(--color-ca-platinum-300)` | 9 |
| `#f1eae2` | `var(--color-ca-platinum-100)` | 7 |
| `#faf8f5` | `var(--color-ca-bone)` | 5 |
| `#7a1b1b` | `var(--color-ca-urgent)` | 3 |

3. Fontes em `layout.tsx`: trocar o `<link>` do Google Fonts por `next/font/google` com `Cormorant_Garamond`, `Instrument_Sans` e `IBM_Plex_Mono` (`display: 'swap'`, `subsets: ['latin']`). Ganho: elimina duas conexões externas e o layout shift.

### R3.2 Arquivo por arquivo

#### `src/app/(frontend)/layout.tsx`
- `metadataBase` → `https://cavalcantealbuquerque.com.br`
- `title.default` → `Cavalcante Albuquerque | Advocacia e Consultoria — Natal/RN`
- `title.template` → `%s | Cavalcante Albuquerque`
- `openGraph.siteName` → `Cavalcante Albuquerque`
- `keywords` → revisar para as áreas efetivas do Dr. Edivaldo
- **Remover** `import './styles.css'`
- **Remover** o JSON-LD hardcoded → mover para componente `<StructuredData />` alimentado pelo global `brand-config` (tipo `LegalService`, com `founder`, `sameAs` das redes, `openingHoursSpecification`, `telephone`, `email`, `geo`)
- `<body>` sai com `style={{}}` → recebe `className="ca-surface-light"`

#### `src/components/layout/Header.tsx`
- Remover o bloco do logo textual (linhas 38–50) → `<Image src="/brand/lockup-light.svg" alt="Cavalcante Albuquerque" width={220} height={55} priority />`
- Adicionar prop `variant?: 'over-hero' | 'solid-light'`; em `solid-light` usar `lockup-dark.svg`, fundo `--ca-paper`, borda inferior `--ca-line`
- `navLinks` deixa de ser array em código → recebe `items` do global `navigation` (ver spec 03)
- Trocar `onMouseEnter/onMouseLeave` que manipulam `style` por classes CSS com `:hover` e `:focus-visible`
- Remover `backdropFilter`
- Menu mobile: adicionar `aria-expanded`, `aria-controls`, focus trap e fechar com `Esc`

#### `src/components/layout/Footer.tsx`
- Nome, e-mail e copyright → do CMS
- `practiceAreas` e `navLinks` hardcoded → do CMS (`navigation.footerColumns`)
- Telefone `(84) 99999-9999` → do CMS (**hoje diverge do SiteConfig**)
- Redes sociais com `href="#"` → URLs reais do CMS; se vazio, **não renderizar o ícone**
- Adicionar na faixa inferior: razão social, CNPJ, OAB/RN, link Política de Privacidade, link Encarregado LGPD
- Aplicar `.ca-surface-dark`

#### Mapa `authorNames` — 4 arquivos
`RecentPosts.tsx:7-10`, `blog/page.tsx:14`, `blog/[slug]/page.tsx:12-14`, `areas-de-atuacao/AreasPageClient.tsx:14-15`

Apagar os quatro. Substituir pela relação `author → team` (collection `Team`, spec 03). O nome vem do registro, não de um dicionário.

#### `src/components/sections/AboutPartners.tsx`
- Renomear o componente para `TeamSection` (não há mais "sócios", há um titular e eventuais associados)
- Fallbacks hardcoded (linhas 15 e 24) → apagar. Sem dados no CMS, a seção não renderiza.
- Título padrão: `"Sócios Fundadores"` → `"Quem conduz o seu caso"`

#### `src/app/(frontend)/sobre/AboutPageClient.tsx`
- `defaultPartners`, `defaultTimeline`, `defaultHistory` → apagar
- A timeline precisa de conteúdo novo: a linha "2025 — Fundação da Cavalcante & Melo" não pode aparecer. Sugestão de estrutura a preencher no CMS: formação e trajetória do Dr. Edivaldo → constituição do escritório atual → marcos de atuação. **Conteúdo a ser escrito pelo cliente**, não gerado.

#### `src/app/(frontend)/admin-tools/cards/page.tsx`
Gerador de cards em canvas — precisa de rebranding completo do desenho:
- Linha 80: watermark `'CM'` → desenhar o símbolo (3 barras) em canvas, opacidade 0.05
- Linha 155: `'CAVALCANTE & MELO'` → `'CAVALCANTE ALBUQUERQUE'`
- Linha 157: `'SOCIEDADE DE ADVOGADOS'` → `'ADVOCACIA E CONSULTORIA'`
- `t.accent` dourado → gradiente de aço via `ctx.createLinearGradient()`
- Fontes: `Georgia` → carregar Cormorant Garamond com `document.fonts.load()` antes de desenhar (senão o canvas usa fallback e o card sai fora da marca)
- Padrão de losangos de fundo (linhas 60–74) → substituir pelo motivo das 3 barras

#### `src/components/admin/AdminLoginGate.tsx`
- Linha 34: marca d'água `'CM'` em 400px → `symbol-mono-light.svg` a 3% de opacidade
- Linha 73: título → `Cavalcante Albuquerque — Painel Interno`
- Ícone `Scale` do Lucide → símbolo da marca

#### `src/app/(frontend)/calculadora/page.tsx:468`
Rodapé do laudo → nome novo + `OAB/RN nº ___`. **Adicionar aviso**: o resultado é estimativa, não constitui parecer nem promessa de resultado (exigência do Provimento 205/2021 da OAB).

#### `src/app/(frontend)/cliente/page.tsx` (211, 347) e `NpsSurvey.tsx:277`
Trocar razão social e placeholder.

#### `src/payload.config.ts`
- `admin.meta.titleSuffix` → `' | Cavalcante Albuquerque'`
- Adicionar `admin.components.graphics.Logo` e `.Icon` apontando para componentes que renderizam o lockup e o símbolo. O painel do Payload hoje mostra o logo genérico.
- Adicionar `admin.meta.icons` com o favicon novo

#### E-mails transacionais — `api/leads`, `api/contact`, `api/nps`, `api/deadlines`
- Remetente `'Site Cavalcante & Melo <onboarding@resend.dev>'` → **`onboarding@resend.dev` é o domínio de sandbox do Resend.** Verificar `cavalcantealbuquerque.com.br` no Resend e usar `Cavalcante Albuquerque <nao-responda@cavalcantealbuquerque.com.br>`. Sem isso os e-mails caem em spam.
- Extrair o HTML dos e-mails para `src/emails/` com um template único de marca (cabeçalho com lockup, cores novas, rodapé com dados institucionais). Hoje o HTML está inline e duplicado em 4 rotas.

#### `.github/workflows/deploy.yml`
- `/var/www/cavalcantemelo` → novo path
- `pm2 reload cavalcantemelo` → novo nome de processo
- Ver spec 07 sobre unificar a estratégia de deploy

#### `README.md`
Reescrever inteiro. É a documentação que o próximo agente vai ler.

---

## R4 · SEO, domínio e migração

### R4.1 Novos arquivos

`src/app/sitemap.ts` — gerado dinamicamente do Payload (páginas estáticas + posts publicados + campanhas ativas + áreas de atuação), com `lastModified` real.

`src/app/robots.ts` — `allow: /`, `disallow: ['/admin', '/admin-tools', '/api', '/cliente']`, `sitemap`.

`generateMetadata` em todas as rotas dinâmicas (`blog/[slug]`, `campanhas/[slug]`, `areas-de-atuacao/[slug]`) com `title`, `description`, `openGraph.images`, `alternates.canonical`. Hoje só `campanhas/[slug]` tem.

### R4.2 Migração de domínio

Se `cavalcantemelo.adv.br` estava indexado, o SEO acumulado não pode ser jogado fora:

1. Manter o domínio antigo ativo por **no mínimo 12 meses**.
2. `301` de cada URL antiga para a equivalente nova, rota a rota (não redirecionar tudo para a home — isso é tratado como soft-404 pelo Google).
3. Implementar via `redirects()` no `next.config.ts` ou no proxy reverso.
4. Google Search Console: registrar a nova propriedade e usar a ferramenta de **Mudança de Endereço**.
5. Atualizar Google Meu Negócio, OAB/RN, JusBrasil, redes sociais, assinaturas de e-mail, papelaria.
6. Deixar por 90 dias uma faixa discreta na home: *"Cavalcante & Melo agora é Cavalcante Albuquerque."* Depois remover.

> **Ponto jurídico a validar com o cliente:** a comunicação da mudança de nome não pode sugerir continuidade societária se a sociedade foi de fato dissolvida. Recomendo que o texto exato dessa faixa seja aprovado pelo Dr. Edivaldo antes de publicar.

---

## R5 · Checklist de aceite

```
[ ] grep de marca antiga retorna zero
[ ] Nenhum #c4a96a no repositório
[ ] Nenhum style={{}} nos componentes de layout e sections
[ ] styles.css do template apagado; my-route apagado; logo-cm.png apagado
[ ] Lockup em SVG no header e no footer, com alt correto
[ ] favicon, apple-icon, manifest, opengraph-image presentes
[ ] Fontes via next/font — zero <link> para fonts.googleapis.com
[ ] Contraste AA verificado em todas as combinações de texto
[ ] Navegação por teclado completa; foco sempre visível
[ ] prefers-reduced-motion respeitado
[ ] Lighthouse ≥ 95 em Performance, Acessibilidade, SEO e Best Practices
[ ] sitemap.xml e robots.txt respondendo
[ ] Campos institucionais pendentes visíveis como __PENDENTE__ no admin, nunca inventados
```
