# 07 — Backlog de execução para o agente de IA

Cada ticket é autocontido: contexto, arquivos, o que fazer, o que **não** fazer, critério de pronto e um prompt copiável.

---

## Regras permanentes do agente

Colar isto no início de **toda** sessão:

```
Projeto: migração do site Cavalcante & Melo para Cavalcante Albuquerque.
Stack: Next.js 16 (App Router) · Payload CMS 3.80 · PostgreSQL · Tailwind v4 · TypeScript.

Sempre:
1. Ler o SPEC do ticket antes de escrever código.
2. Rodar `tsc --noEmit` ao terminar. Zero erro.
3. Após mudança de schema: `payload generate:types` e criar migration —
   NUNCA usar db push em produção.
4. Após criar/alterar componente do admin: `payload generate:importmap`.
5. Em hooks, passar sempre `req` para operações aninhadas (atomicidade).
6. Ao passar `user` para a Local API, sempre `overrideAccess: false`.
7. Usar tokens CSS. Nenhum literal hexadecimal novo. Nenhum `style={{}}` novo.
8. Trabalhar em branch por ticket: `feat/<id>-<slug>`.

Nunca:
- Inventar dado institucional (CNPJ, OAB, razão social, endereço). Usar "__PENDENTE__".
- Apagar ou reatribuir conteúdo assinado pela ex-sócia sem instrução explícita.
- Rodar migração destrutiva sem backup verificado.
- Escrever copy que prometa resultado (Provimento OAB 205/2021).
- Publicar conteúdo gerado por IA sem revisão humana registrada.
```

---

## Fase 0 — Segurança (P0, bloqueante)

### SEC-01 · Controle de acesso
**Spec:** 05 §1 · **Arquivos:** `src/access/*` (criar), todas as `src/collections/*.ts`, `src/globals/*.ts`
**Fazer:** criar as funções de acesso; aplicar a matriz da spec; adicionar `roles` em Users com `saveToJWT`; desabilitar REST/GraphQL automáticos em Leads, ClientDocuments, NpsResponses, CampaignEvents.
**Não fazer:** alterar a lógica de negócio das rotas de API ainda.
**Pronto quando:** `curl -X GET /api/leads` sem sessão → 403. `curl -X PATCH /api/globals/site-config` → 403. Admin logado continua funcionando em tudo.

```
Aplique a matriz de controle de acesso da spec 05 §1.4 ao projeto Payload.
Crie src/access/ com anyone, authenticated, adminOnly, adminOrEditor, adminOrStaff,
publishedOnly, ownClientData, adminOrSelf. Adicione o campo roles à collection Users
(select hasMany, saveToJWT: true, opções admin/editor/staff/client, update só por admin).
Substitua todo access: () => true pelas funções corretas. Em Leads, ClientDocuments,
NpsResponses e CampaignEvents, defina endpoints: false e graphQL: false — a criação
passará só pelas rotas de API próprias. Gere types e migration. Rode tsc --noEmit.
```

### SEC-02 · Segredos e Dockerfile
**Spec:** 05 §2.3, §3.1 · **Arquivos:** `Dockerfile`, `.env.example`, `api/news-feed`, `api/revalidate`, `api/deadlines`, `api/petition-generator`
**Fazer:** remover credenciais do Dockerfile; separar `CRON_SECRET` / `REVALIDATE_SECRET` / `N8N_WEBHOOK_SECRET`; eliminar defaults hardcoded (503 se ausente); comparação com `timingSafeEqual`; reescrever `.env.example` completo.
**Pronto quando:** nenhum segredo no repositório; rota sem env configurada responde 503; `grep -r "cm2026admin"` vazio.

### SEC-03 · Autenticação do painel interno
**Spec:** 05 §2.1 · **Arquivos:** `middleware.ts` (criar), `admin-tools/*`, `components/admin/*`
**Fazer:** middleware validando sessão do Payload em `/admin-tools/*`; rotas internas checando `req.user` e papel; apagar `AdminAuthContext` e `AdminLoginGate`.
**Pronto quando:** `/admin-tools` sem sessão redireciona para login; API interna sem sessão → 401.

### SEC-04 · Rate limit, honeypot e consentimento
**Spec:** 05 §3.3, §4 · **Arquivos:** `api/leads`, `api/contact`, `api/nps`, `api/datajud`, `CampaignLeadForm`, `ContactForm`
**Fazer:** 5 req/10min por IP; honeypot + verificação de tempo; checkbox de consentimento obrigatório com `consentText`, `consentedAt`, `ip`, `userAgent`; remover CPF do formulário público de campanha.
**Pronto quando:** 6ª requisição → 429; envio sem consentimento → 400; registro grava a prova completa.

### SEC-05 · Cabeçalhos e limpeza
**Spec:** 05 §3.2, §3.4 · **Arquivos:** `next.config.ts`, `my-route/`, `docker-compose.yml`
**Fazer:** cabeçalhos de segurança (CSP em report-only); apagar `src/app/my-route/`; reescrever `docker-compose.yml` para Postgres.

---

## Fase 1 — Dissolução da sociedade (P0)

### TEAM-01 · Collection Team
**Spec:** 03 §A2 · **Pronto quando:** collection criada, migration aplicada, dois registros semeados (Edivaldo ativo; Gabrielly inativa e `formerMember: true`).

### TEAM-02 · Campos relacionais paralelos
**Spec:** 03 §A3 passo 3
**Fazer:** adicionar `authorRef`, `assignedToRef`, `responsibleRef`, `attorneyRef` **ao lado** dos enums. Não remover nada.
**Pronto quando:** schema aceito, site funcionando exatamente como antes.

### TEAM-03 · Backfill
**Spec:** 03 §A3 passo 4 · **Arquivo:** `scripts/migrate-team-refs.ts`
**Fazer:** script idempotente com `--dry-run` obrigatório antes; mapear os quatro valores; relatório final.
**Não fazer:** rodar sem backup verificado; apagar coluna nenhuma.
**Pronto quando:** dry-run mostra zero não mapeados; execução real bate os totais; conferência manual de 10 registros por collection.

```
Escreva scripts/migrate-team-refs.ts usando a Local API do Payload.
Para Posts.author, PracticeAreas.responsible, Leads.assignedTo, Clients.responsible,
Deadlines.attorney e NpsResponses.attorney: mapeie 'edivaldo' e 'gabrielly' para os IDs
correspondentes em team; 'escritorio' e 'both' para null com byFirm: true.
Suporte a --dry-run (padrão) e --commit. Processe em lotes de 100 com log de progresso.
Ao final imprima: lidos, escritos, pulados, não mapeados por collection.
Não remova nenhum campo. Não altere schema.
```

### TEAM-04 · Frontend lendo a relação
**Fazer:** apagar os 4 mapas `authorNames` duplicados; ler nome/foto/OAB do registro Team.

### TEAM-05 · Remoção dos enums
**Pré-requisito:** TEAM-04 em produção há 48h sem incidente.
**Fazer:** drop das colunas antigas; renomear `*Ref` para o nome final; migration.

### TEAM-06 · Curadoria de conteúdo (⚠ requer decisão humana)
**Fazer:** listar todo conteúdo público que referencia a ex-sócia (posts, áreas, depoimentos, fotos, timeline) e **apresentar a lista ao Dr. Edivaldo para decisão item a item**.
**Não fazer:** despublicar, reatribuir ou apagar por conta própria.

---

## Fase 2 — Identidade visual (P1)

### BRAND-01 · Assets
**Spec:** 02 §R2 · **Pronto quando:** `public/brand/` completo, favicon/apple-icon/manifest/opengraph-image no lugar, `logo-cm.png` apagado, tile do watermark repetindo sem emenda.

### BRAND-02 · Tokens
**Spec:** 02 §R3.1 + `assets/tokens.css` · **Pronto quando:** `globals.css` substituído; `styles.css` do template apagado e o import removido de `layout.tsx`; zero `#c4a96a` e zero `#152138` no repositório; fontes por `next/font`.

### BRAND-03 · Header e Footer
**Spec:** 02 §R3.2 · **Pronto quando:** lockup SVG no lugar do texto "CM"; variante `over-hero`/`solid-light`; nav e colunas vindas do CMS; hover por CSS com `:focus-visible`; menu mobile acessível.

### BRAND-04 · Seções e páginas
**Fazer:** migrar `style={{}}` para classes de token em todas as `components/sections/*` e páginas; aplicar A Escala (régua, marcador, varredura).
**Pronto quando:** nenhum `style={{}}` em `components/` e `app/(frontend)/` exceto valores realmente dinâmicos.

### BRAND-05 · Metadados e SEO
**Spec:** 02 §R3.2, §R4.1 · **Pronto quando:** `layout.tsx` atualizado; `sitemap.ts` e `robots.ts` criados; `generateMetadata` em todas as rotas dinâmicas; JSON-LD vindo do CMS.

### BRAND-06 · Painel Payload e e-mails
**Fazer:** logo e ícone customizados no admin; `titleSuffix`; template único de e-mail em `src/emails/` com a marca nova; remetente com domínio verificado no Resend.

### BRAND-07 · Gerador de cards
**Spec:** 02 §R3.2 · **Fazer:** rebranding completo do canvas (símbolo, cores, gradiente, fontes carregadas antes do desenho, motivo de fundo).

### BRAND-08 · Redirecionamentos e domínio
**Spec:** 02 §R4.2 · **Fazer:** mapa 301 rota a rota; Search Console; faixa temporária de mudança de nome (texto aprovado pelo cliente).

---

## Fase 3 — CMS-first (P1)

### CMS-01 · Global `brand-config` (spec 03 §B1)
### CMS-02 · Global `navigation` (spec 03 §B1)
### CMS-03 · Global `automation-config` (spec 03 §B1)
### CMS-04 · Homepage por blocos (spec 03 §B2)
### CMS-05 · Collections novas: Faqs, AutomationRuns, AuditLog (spec 03 §B3)
### CMS-06 · Ajustes nas collections existentes (spec 03 §B4)

**Pronto (fase inteira):** trocar telefone, menu, ordem das seções, área de atuação e texto de qualquer seção não exige deploy.

---

## Fase 4 — Performance e dinamismo (P2)

### PERF-01 · ISR + revalidate por hook
**Spec:** 06 §1 · **Pronto quando:** `force-dynamic` removido; hook aplicado em todas as collections publicáveis e globals; salvar no admin reflete no site em ≤10s; TTFB da home ≤150ms.

### PERF-02 · Bundle e imagens
**Spec:** 06 §5 · **Pronto quando:** JS inicial ≤140KB gzip; `next/image` em tudo; rotas pesadas em `dynamic()`.

### UX-01 · Acessibilidade
**Spec:** 06 §6 · **Pronto quando:** checklist completo e teste real com leitor de tela.

### UX-02 · Movimento
**Spec:** 06 §4 · **Pronto quando:** orquestração implementada e `prefers-reduced-motion` respeitado.

### UX-03 · Páginas novas
**Spec:** 06 §7 — privacidade, termos, faq, equipe/[slug], obrigado, not-found, error, loading.

---

## Fase 5 — Automação (P2)

### AUTO-01 · Jobs Queue + AutomationRuns + HealthCheck (spec 04 §0)
### AUTO-02 · DeadlineAlertTask (spec 04 §4) — *maior valor por hora investida; a rota já existe*
### AUTO-03 · Leads: dedupe, SLA, triagem por IA, resposta automática, nutrição (spec 04 §2)
### AUTO-04 · FetchNews v2 + CurateNews (spec 04 §1.1–1.2)
### AUTO-05 · SyncDatajud + ProcessMovements (spec 04 §3)
### AUTO-06 · NPS automático + depoimento com consentimento (spec 04 §5)
### AUTO-07 · Portal do cliente com código por WhatsApp (spec 05 §2.2)
### AUTO-08 · SocialAssetTask (spec 04 §6.1)
### AUTO-09 · Pauta editorial + rascunho assistido com trava de revisão (spec 04 §1.3–1.4)
### AUTO-10 · Painel de automações (spec 04 §7)
### AUTO-11 · Contrato de webhook n8n assinado (spec 04 §2.2)

---

## Fase 6 — Operação (P3)

### OPS-01 · Unificar deploy
Escolher **uma** estratégia (recomendo Docker + EasyPanel, já documentada no README) e apagar a outra. Hoje `deploy.yml` faz SSH+pm2 num path que não existirá mais.

### OPS-02 · Migrations no pipeline
`payload migrate` como passo do deploy, com falha bloqueando o release. Hoje é passo manual no terminal do painel — e por isso é esquecido.

### OPS-03 · Backup
`pg_dump` diário + retenção 30 dias + **teste mensal de restauração**. Backup não testado não é backup.

### OPS-04 · Observabilidade
Sentry (front e back), alerta de job falho, uptime externo.

### OPS-05 · Testes
Atualizar os e2e existentes (apontam para conteúdo antigo); adicionar cobertura para controle de acesso — teste que garante que `GET /api/leads` sem sessão retorna 403 evita a regressão mais cara possível.

### OPS-06 · README
Reescrever inteiro. É o que o próximo agente vai ler.

---

## Marcos de revisão humana

Não avançar sem aprovação nestes cinco pontos:

| Marco | Quem aprova | O quê |
|---|---|---|
| M1 — fim da Fase 0 | Técnico | As APIs públicas estão fechadas? |
| M2 — antes de TEAM-05 | Dr. Edivaldo | O backfill está correto? Backup restaurável? |
| M3 — TEAM-06 | Dr. Edivaldo | Destino de cada conteúdo da ex-sócia |
| M4 — fim da Fase 2 | Dr. Edivaldo | A marca está aplicada como ele espera? |
| M5 — antes do go-live | Dr. Edivaldo + OAB/RN | Copy conforme o Provimento 205/2021 |

---

## Ordem sugerida por semana

```
S1   SEC-01 · SEC-02 · SEC-05
S2   SEC-03 · SEC-04 · TEAM-01 · TEAM-02
S3   TEAM-03 · TEAM-04 · BRAND-01 · BRAND-02          → M1, M2
S4   BRAND-03 · BRAND-04
S5   BRAND-05 · BRAND-06 · BRAND-07 · TEAM-05 · TEAM-06 → M3, M4
S6   CMS-01..06 · PERF-01
S7   PERF-02 · UX-01..03 · BRAND-08                    → M5, go-live
S8+  AUTO-01..11 · OPS-01..06
```

**Lançar nas semanas 1–7. As automações entram com o site já no ar** — cada uma agrega valor sozinha e nenhuma bloqueia o rebranding.
