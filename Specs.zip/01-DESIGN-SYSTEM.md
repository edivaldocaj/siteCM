# 01 — Sistema de identidade digital · Cavalcante Albuquerque

Todos os valores abaixo foram **amostrados dos arquivos de marca enviados**, não estimados.
Fonte da amostragem: `logmarca.png`, `logo111.png`, `marca.png`, `logomarca_branca.png`.

---

## 1. Direção

A marca antiga era **navy + dourado** — o vocabulário padrão de escritório de advocacia brasileiro. A nova é **navy profundo + metal escovado**. Essa diferença não é decorativa: dourado comunica tradição e status; aço escovado comunica precisão, engenharia, solidez construída. O próprio símbolo — três barras ascendentes, com a primeira em navy e ponta de pena — diz "estrutura que sobe". O tagline oficial confirma: *"Advocacia com estratégia e solidez."*

**A regra que governa tudo:** o dourado morre. Não há `#c4a96a` no projeto novo, em lugar nenhum, nem como fallback.

**Público:** empresas e pessoas físicas em Natal/RN que precisam de assessoria continuada (Digital/LGPD, Civil, Consumidor, Imobiliário, Tributário, Licitações) e defesa criminal com urgência.
**Trabalho da homepage:** transformar um visitante em conversa de WhatsApp qualificada em menos de 20 segundos, sem parecer um funil de infoproduto.

---

## 2. Paleta

### 2.1 Navy (fundo e tinta)

| Token | Hex | Origem | Uso |
|---|---|---|---|
| `--ca-navy-950` | `#011536` | amostrado de `logmarca.png` | Fundo primário escuro, tinta sobre claro |
| `--ca-navy-900` | `#041834` | amostrado de `logo111.png` | Superfície de cartão sobre navy-950 |
| `--ca-navy-800` | `#0A2049` | derivado | Estados hover em superfície escura |
| `--ca-navy-700` | `#14305E` | derivado | Bordas, divisores sobre escuro |
| `--ca-navy-600` | `#1F4275` | derivado | Foco de teclado sobre escuro |

> O navy antigo `#152138` era 12% mais claro e mais dessaturado. Trocar direto por `#011536` deixa o site visivelmente mais denso e caro. É o efeito desejado.

### 2.2 Metal escovado (substitui o dourado)

| Token | Hex | Origem | Uso |
|---|---|---|---|
| `--ca-steel-900` | `#5C646E` | amostrado | Sombra do metal, texto desativado sobre claro |
| `--ca-steel-700` | `#6E7A8A` | amostrado | Ícones secundários |
| `--ca-steel-500` | `#8B98AC` | amostrado | **Acento principal** — o "novo dourado" |
| `--ca-steel-400` | `#99A8BB` | amostrado | Texto secundário sobre navy |
| `--ca-platinum-300` | `#D0D2D9` | amostrado | Texto de corpo sobre navy |
| `--ca-platinum-100` | `#EEF1F4` | amostrado | Highlight do metal, títulos sobre navy |

**Gradiente assinatura** (o brilho real do símbolo, com o realce fora do centro):
```css
--ca-gradient-steel: linear-gradient(
  100deg,
  #5C646E 0%, #8B98AC 14%, #EEF1F4 34%, #AEB8C4 52%, #6E7A8A 76%, #D0D2D9 100%
);
```
Usar em: régua das seções, borda superior de card em destaque, texto do H1 da home (`background-clip: text`), preenchimento das barras do símbolo em SVG. **Nunca** em fundo de botão grande — vira plástico.

### 2.3 Neutros claros

| Token | Hex | Origem | Uso |
|---|---|---|---|
| `--ca-bone` | `#F8F6F4` | amostrado de `marca.png` | Fundo de seção clara (o padrão do site) |
| `--ca-paper` | `#FBFAFA` | amostrado de `logomarca_branca.png` | Cartões sobre bone |
| `--ca-line` | `#E4E2DF` | derivado | Divisores sobre claro |

### 2.4 Sinais funcionais

| Token | Hex | Uso |
|---|---|---|
| `--ca-whatsapp` | `#25D366` | Exclusivo do botão WhatsApp. Nunca como acento genérico. |
| `--ca-urgent` | `#7E2230` | Faixa criminal 24h. Bordô profundo, não vermelho de alerta — convive com navy sem gritar. Substitui `#7a1b1b`. |
| `--ca-success` | `#2F6D52` | Confirmação de formulário |
| `--ca-warning` | `#8A6A2F` | Prazo próximo no painel interno |

### 2.5 Contraste (WCAG AA obrigatório)

| Combinação | Razão | Veredito |
|---|---|---|
| `platinum-100` sobre `navy-950` | 15.9:1 | AAA |
| `platinum-300` sobre `navy-950` | 11.4:1 | AAA |
| `steel-400` sobre `navy-950` | 6.8:1 | AA |
| `steel-500` sobre `navy-950` | 5.4:1 | AA (só ≥16px) |
| `navy-950` sobre `bone` | 16.2:1 | AAA |
| `steel-700` sobre `bone` | 4.6:1 | AA |
| `steel-500` sobre `bone` | 3.1:1 | **Reprovado para texto** — só ícone/borda |

Regra: `steel-500` é acento estrutural, não cor de texto sobre fundo claro.

---

## 3. Tipografia

O letreiro da marca usa uma serifa de alto contraste em caixa alta com tracking largo, e um sans espaçado no descritor. Playfair Display (atual) é mais pesada e mais moderna que isso — não combina com o lockup.

| Papel | Fonte | Por quê | Pesos |
|---|---|---|---|
| **Display** | **Cormorant Garamond** | Serifa de alto contraste, hastes finas, caixa alta elegante em tracking largo. É a família que mais se aproxima do letreiro real. | 300, 400, 500, 600 |
| **Corpo / UI** | **Instrument Sans** | Grotesca neutra, levemente estreita, sem a onipresença do Inter. Boa em 14–16px, boa em caixa alta espaçada (descritor "ADVOCACIA E CONSULTORIA"). | 400, 500, 600 |
| **Dados** | **IBM Plex Mono** | Números de processo CNJ (`0801234-56.2025.8.20.0001`), CPF, valores e datas em tabela. Numerais tabulares evitam salto de coluna. | 400, 500 |

Esse trio não é decorativo: o mono existe porque um escritório lê números CNJ o dia inteiro, e a fonte proporcional os torna ilegíveis em lista.

### Escala tipográfica

```
display-xl   clamp(2.75rem, 6vw, 5rem)   Cormorant 500   line-height 1.05   tracking -0.01em
display-lg   clamp(2rem, 4vw, 3.25rem)   Cormorant 500   line-height 1.12   tracking  0
display-md   clamp(1.5rem, 2.6vw, 2rem)  Cormorant 600   line-height 1.2    tracking  0
eyebrow      0.6875rem                   Instrument 600  tracking 0.28em    UPPERCASE
body-lg      1.125rem                    Instrument 400  line-height 1.65
body         1rem                         Instrument 400  line-height 1.7
caption      0.8125rem                   Instrument 400  line-height 1.55
data         0.875rem                    Plex Mono 400   tracking 0.02em
```

### Regras de uso

- **O lockup nunca é recriado em HTML.** Onde a marca aparece, é imagem/SVG. O `Header` atual desenha `"CM"` em Playfair — isso sai.
- Caixa alta em display só com `letter-spacing: 0.14em` ou mais. Cormorant em caps apertadas fica ilegível.
- Nada de `font-weight: bold` em Cormorant. Máximo 600.
- Corpo de texto nunca em Cormorant. Serifa de alto contraste em 16px cansa.

---

## 4. O elemento assinatura — "A Escala"

Uma página precisa de uma coisa memorável. Aqui é o próprio símbolo virado sistema estrutural.

**As três barras ascendentes deixam de ser só logo e viram gramática de layout:**

1. **Régua de seção.** Todo cabeçalho de seção carrega três traços verticais de alturas crescentes (8px / 14px / 20px), alinhados à esquerda do eyebrow. A primeira barra é navy sólida; as duas seguintes usam o gradiente de aço. É a única decoração recorrente do site.

```
▌▌▌  ÁREAS DE ATUAÇÃO
      Como podemos atuar no seu caso
```

2. **Marcador de lista.** Itens de lista usam a barra 1 (navy, com a ponta inferior de pena) como bullet, em 6×14px. Substitui o disco padrão. Não usar numeração 01/02/03 — não há sequência real no conteúdo.

3. **Progresso de leitura.** Em artigos do blog, a barra do topo preenche com o gradiente de aço conforme o scroll. Uma barra, 2px, sem número, sem porcentagem.

4. **Varredura no hover.** Cards de área de atuação e de campanha recebem um sweep do gradiente de aço na borda superior (300ms, `ease-out`), da esquerda para a direita. Um efeito, um lugar. Respeitando `prefers-reduced-motion: reduce` → sem sweep, só mudança de borda.

**Restrição deliberada:** nada de glassmorphism, nada de blur, nada de gradiente de fundo colorido. O `glass-card` atual (`backdrop-filter: blur(12px)`) sai. Fundo navy chapado, superfícies levemente elevadas por `navy-900`, uma borda `navy-700` de 1px. A elegância aqui vem de espaçamento e tipografia, não de efeito.

---

## 5. Espaçamento, grade e forma

```
--ca-space: 4px base   →  4 · 8 · 12 · 16 · 24 · 32 · 48 · 64 · 96 · 128
--ca-container: 1200px (conteúdo)  /  1360px (largo)
--ca-gutter: 20px mobile · 32px tablet · 48px desktop
--ca-radius-sm: 2px    (botões, tags)
--ca-radius-md: 4px    (cards)
--ca-radius-lg: 12px   (só o ícone de app, espelhando o logo)
```

Raio quase zero é escolha: o símbolo tem cantos retos e chanfros. Card com `border-radius: 16px` briga com a marca.

**Elevação:** sem sombra colorida. Duas sombras apenas.
```css
--ca-shadow-sm: 0 1px 2px rgba(1,21,54,0.06), 0 2px 8px rgba(1,21,54,0.04);
--ca-shadow-md: 0 8px 24px rgba(1,21,54,0.10), 0 2px 6px rgba(1,21,54,0.06);
```

---

## 6. Componentes-chave

### Botões

| Variante | Fundo | Texto | Borda | Uso |
|---|---|---|---|---|
| `primary` | `navy-950` | `platinum-100` | — | Ação principal em fundo claro |
| `primary-invert` | `platinum-100` | `navy-950` | — | Ação principal em fundo navy |
| `whatsapp` | `#25D366` | `#FFFFFF` | — | Só WhatsApp |
| `ghost` | transparente | `steel-400` | 1px `steel-700` | Ação secundária |
| `urgent` | `--ca-urgent` | `#FFFFFF` | — | Só plantão criminal |

Todos: `padding: 14px 28px`, `Instrument Sans 600`, `13px`, `uppercase`, `letter-spacing: .12em`, `radius 2px`.
Hover: inverte fundo e texto (300ms). **Foco visível obrigatório:** `outline: 2px solid var(--ca-steel-500); outline-offset: 2px`.

### Cabeçalho

Estado inicial: transparente sobre o hero, lockup em versão clara (`lockup-light.svg`).
Após 20px de scroll: fundo `rgba(1,21,54,0.94)`, altura reduzida, **sem** `backdrop-filter`.
Em páginas de fundo claro: fundo `--ca-paper` com borda inferior `--ca-line` e lockup em versão escura (`lockup-dark.svg`).

Isso exige que o Header saiba em que tipo de página está — passar `variant: 'over-hero' | 'solid-light'` via prop do layout.

### Rodapé

Fundo `navy-950`. Quatro colunas em desktop, duas em tablet, uma em mobile.
Coluna 1: lockup claro + tagline + selos. As demais são **geradas do CMS**, não hardcoded.
Faixa inferior: razão social completa, CNPJ, número de registro OAB/RN da sociedade, link para Política de Privacidade e para o Encarregado de Dados (LGPD).

---

## 7. Assets de marca — mapeamento dos arquivos enviados

| Arquivo enviado | Dimensão | O que é | Destino no projeto | Tratamento necessário |
|---|---|---|---|---|
| `logmarca.png` | 2508×627 | Lockup horizontal, letreiro claro sobre navy | `public/brand/lockup-light.png` + `.webp` | Recortar fundo → PNG com alpha. **Vetorizar → `lockup-light.svg`** |
| `logomarca_branca.png` | 2508×627 | Lockup horizontal, letreiro navy sobre osso | `public/brand/lockup-dark.png` + `.webp` | Idem. Usar em header claro, e-mails, PDFs |
| `logo111.png` | 1254×1254 | Ícone de app, navy, canto arredondado | `public/brand/icon-app.png` | Gerar favicon 16/32/48, `apple-icon` 180, maskable 512, `icon.svg` |
| `log.png` | 1024×1024 (alpha) | Duas variantes de ícone (quadrado + redondo) sobre branco | `public/brand/icon-square.png`, `icon-round.png` | **Separar em dois arquivos.** Redondo = avatar de rede social |
| `logo_mini.png` | 1254×1254 | Mesmas duas variantes, fundo osso | fonte alternativa | Usar se `log.png` tiver franja no recorte |
| `marca.png` | 1672×941 | Padrão de marca d'água, tom sobre tom | `public/brand/pattern-watermark.png` | Recortar **tile perfeito** (unidade que repete sem emenda). Fundo de seções claras a ≤3% de opacidade |
| `marca_1.png` | 1731×909 | Apresentação da marca com tagline | `public/brand/og-default.jpg` (1200×630) | Recorte central. Imagem OG padrão do site |
| `marca_2.png` | 1672×941 | Capa "Fale Conosco" | `public/brand/cover-contato.jpg` | Hero da página `/contato` e OG dessa rota |
| `areas_atuacao.png` | 1672×941 | Capa "Áreas de Atuação" | `public/brand/cover-areas.jpg` | Hero da `/areas-de-atuacao` e OG dessa rota |

### Alerta técnico sobre os assets

Sete dos nove arquivos estão em **RGB sem canal alpha** — são mockups renderizados, não artes vetoriais. Consequências:

- O lockup **não pode** ser sobreposto a fundos diferentes sem recorte manual.
- Em tamanhos pequenos (header 32px de altura), a textura metálica vira ruído cinza.
- O favicon a 16×16 a partir de `logo111.png` fica ilegível.

**Ação obrigatória:** vetorizar símbolo e lockup. Enquanto o vetor oficial da agência não chega, use o arquivo `assets/ca-symbol.svg` deste pacote — traçado técnico derivado por medição do bitmap (geometria confirmada: barra 1 x 388→499 / topo 495→407 / base 1027 / ponta 1080; barra 2 x 585→698; barra 3 x 780→893, na caixa de 1254px). É fiel em proporção e pode ir para produção como ícone e favicon.

### Regras de aplicação da marca

- **Área de respiro:** metade da altura do símbolo em todos os lados. Nada encosta.
- **Tamanho mínimo:** lockup horizontal 140px de largura; símbolo isolado 24px.
- **Fundos permitidos:** `navy-950`, `navy-900`, `bone`, `paper`, ou foto com overlay navy ≥70%.
- **Proibido:** rotacionar, aplicar sombra, alterar a proporção entre símbolo e letreiro, colorir as barras fora da paleta, usar o lockup sobre imagem sem overlay.

---

## 8. Voz e texto de interface

Os textos da interface são material de projeto. Regras:

- **Voz ativa e concreta.** "Enviar mensagem", não "Submeter". "Ver minhas movimentações", não "Acessar módulo processual".
- **Uma ação mantém o mesmo nome do começo ao fim.** O botão "Enviar mensagem" produz a confirmação "Mensagem enviada".
- **Sem promessa de resultado.** Provimento 205/2021 da OAB veda mercantilização. Proibido: "ganhe", "receba seu dinheiro", "garantimos", "sucesso garantido", contador de vitórias. Permitido: "verifique se o seu caso se enquadra", "análise inicial sem custo", "atendimento em até X horas".
- **Erro explica o que fazer.** "Não conseguimos enviar. Verifique o telefone e tente de novo." Não: "Erro ao processar requisição."
- **Vazio convida.** Painel sem prazos → "Nenhum prazo cadastrado. Adicione o primeiro para receber alertas automáticos." Não "Sem registros."
- **Tagline oficial:** *Advocacia com estratégia e solidez.* Usar como assinatura, não como título de seção.

---

## 9. Movimento

`framer-motion` já está instalado e quase não é usado — é peso morto hoje e oportunidade agora.

| Momento | Comportamento | Duração |
|---|---|---|
| Carregamento do hero | Eyebrow → título → subtítulo → CTAs, escalonado 60ms, `y: 12px → 0`, opacidade 0 → 1 | 420ms total |
| Entrada de seção | Uma vez, ao entrar no viewport, `y: 16px → 0` | 320ms |
| Card em hover | Sweep de aço na borda superior + elevação `shadow-sm → shadow-md` | 300ms |
| Régua de seção | Barras crescem de 0 até a altura final, escalonadas | 240ms |
| Contador do TrustBar | Interpola até o valor, uma vez | 900ms |

**Toda animação dentro de `@media (prefers-reduced-motion: no-preference)`.** Com movimento reduzido: estado final imediato, sem exceção.

Nada de parallax, nada de elemento flutuando em loop, nada de partícula. Um escritório de advocacia que se move demais parece startup.

---

## 10. Antes e depois — resumo visual

| | Antes | Depois |
|---|---|---|
| Acento | Dourado `#c4a96a` | Aço escovado `#8B98AC` + gradiente |
| Navy | `#152138` | `#011536` |
| Display | Playfair Display | Cormorant Garamond |
| Corpo | Source Sans 3 | Instrument Sans |
| Dados | — | IBM Plex Mono |
| Logo no header | Texto "CM" em serifa | Lockup SVG real |
| Superfícies | Glassmorphism com blur | Navy chapado, borda 1px |
| Raio | 8px variado | 2px / 4px / 12px (só ícone) |
| Elemento memorável | Nenhum | A Escala (3 barras como sistema) |
| Estilo | `style={{}}` inline | Tokens CSS + Tailwind v4 |
